import React from "react";

const VARIANTS: Record<string, string> = {
  pine: "bg-pine-100 text-pine-700",
  amber: "bg-amber-100 text-amber-700",
  red: "bg-red-100 text-red-700",
  blue: "bg-blue-100 text-blue-700",
  sand: "bg-sand-200 text-ink-900/60",
  gray: "bg-gray-100 text-gray-600",
};

interface BadgeProps {
  children: React.ReactNode;
  variant?: string;
  className?: string;
}

export default function Badge({ children, variant = "sand", className = "" }: BadgeProps) {
  return (
    <span className={`inline-flex items-center text-xs px-2 py-0.5 rounded-full font-medium ${VARIANTS[variant] ?? VARIANTS.sand} ${className}`}>
      {children}
    </span>
  );
}
