import React from "react";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  icon?: React.ReactNode;
}

export default function Input({ label, error, hint, icon, className = "", id, ...props }: InputProps) {
  const inputId = id || (label ? label.toLowerCase().replace(/\s+/g, "-") : undefined);
  return (
    <div className="space-y-1">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-medium text-ink-900/60">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30 pointer-events-none">
            {icon}
          </span>
        )}
        <input
          id={inputId}
          aria-invalid={!!error}
          aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
          className={`w-full px-3 py-2 rounded-lg border text-sm outline-none transition
            ${icon ? "pl-9" : ""}
            ${error ? "border-red-400 focus:border-red-500 focus:ring-red-500/20" : "border-sand-200 focus:border-pine-500 focus:ring-pine-500/20"}
            focus:ring-2 ${className}`}
          {...props}
        />
      </div>
      {error && <p id={`${inputId}-error`} className="text-xs text-red-600" role="alert">{error}</p>}
      {hint && !error && <p id={`${inputId}-hint`} className="text-xs text-ink-900/40">{hint}</p>}
    </div>
  );
}
