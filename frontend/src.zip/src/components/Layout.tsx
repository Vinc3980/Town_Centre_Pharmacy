import React, { useState } from "react";
import { NavLink, Outlet, Link } from "react-router-dom";
import {
  LayoutDashboard, ShoppingCart, ClipboardList, LogOut, CircleDot, Receipt,
  RotateCcw, DollarSign, Clock, BarChart3, Shield, Settings, Menu, X, Users,
  AlertTriangle, Pill, UsersRound, RefreshCw, Search, ChevronDown,
  ArrowDownToLine, ArrowLeftRight, ClipboardCheck, UserCog, Truck, Plus,
} from "lucide-react";
import { createPortal } from "react-dom";
import { useAuth } from "../context/AuthContext";
import NotificationBell from "./NotificationBell";

interface NavItem {
  to: string;
  label: string;
  icon: React.ElementType;
  end?: boolean;
  roles: string[];
  permissions?: string[];
}

interface NavSection {
  title: string;
  items: NavItem[];
  roles: string[];
}

const NAV_SECTIONS: NavSection[] = [
  {
    title: "Main",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true, roles: ["staff", "branch_manager", "admin"] },
    ],
  },
  {
    title: "Inventory",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/medicines", label: "Medicines", icon: Pill, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_medicines"] },
      { to: "/inventory-alerts", label: "Inventory Alerts", icon: AlertTriangle, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_inventory"] },
    ],
  },
  {
    title: "Stock",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/stock-transfer", label: "Stock Transfer", icon: ArrowLeftRight, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_inventory"] },
      { to: "/stock-adjustment", label: "Stock Adjustment", icon: ArrowDownToLine, roles: ["staff", "branch_manager", "admin"], permissions: ["perform_stock_adjustment"] },
    ],
  },
  {
    title: "Sales",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/pos", label: "Point of Sale", icon: ShoppingCart, roles: ["staff", "branch_manager", "admin"] },
      { to: "/sales", label: "Sales", icon: Receipt, roles: ["staff", "branch_manager", "admin"], permissions: ["view_reports"] },
      { to: "/refunds", label: "Sales Return", icon: RotateCcw, roles: ["staff", "branch_manager", "admin"], permissions: ["process_refunds"] },
    ],
  },
  {
    title: "Purchases",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/purchases", label: "Purchases", icon: Truck, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_inventory"] },
      { to: "/purchase-orders", label: "Purchase Orders", icon: ClipboardCheck, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_inventory"] },
    ],
  },
  {
    title: "Finance",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/expenses", label: "Expenses", icon: DollarSign, roles: ["staff", "branch_manager", "admin"], permissions: ["manage_expenses"] },
      { to: "/daily-session", label: "Daily Session", icon: Clock, roles: ["staff", "branch_manager", "admin"] },
    ],
  },
  {
    title: "People",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/customers", label: "Customers", icon: UsersRound, roles: ["staff", "branch_manager", "admin"] },
    ],
  },
  {
    title: "Reports",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/reports", label: "Reports", icon: BarChart3, roles: ["staff", "branch_manager", "admin"], permissions: ["view_reports"] },
    ],
  },
  {
    title: "Activity",
    roles: ["staff", "branch_manager", "admin"],
    items: [
      { to: "/activity", label: "Activity", icon: ClipboardList, roles: ["staff", "branch_manager", "admin"] },
      { to: "/audit", label: "Audit Logs", icon: Shield, roles: ["staff", "branch_manager", "admin"], permissions: ["view_audit_logs"] },
    ],
  },
  {
    title: "User Management",
    roles: ["admin"],
    items: [
      { to: "/users", label: "Users", icon: UserCog, roles: ["admin"] },
    ],
  },
  {
    title: "Settings",
    roles: ["admin"],
    items: [
      { to: "/settings", label: "Settings", icon: Settings, roles: ["admin"] },
    ],
  },
];

function UserAvatar({ src, name, size = "md" }: { src?: string | null; name: string; size?: "sm" | "md" }) {
  const initials = name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase();
  const sizeClasses = size === "sm" ? "w-7 h-7 text-[10px]" : "w-9 h-9 text-xs";

  if (src) {
    return (
      <img
        src={src}
        alt={name}
        className={`${sizeClasses} rounded-full object-cover ring-2 ring-white/10`}
      />
    );
  }

  return (
    <div className={`${sizeClasses} rounded-full bg-orange-500 text-white flex items-center justify-center font-medium ring-2 ring-white/10`}>
      {initials}
    </div>
  );
}

function SidebarSection({ section, userRole, userPermissions }: { section: NavSection; userRole: string; userPermissions: string[] }) {
  const [expanded, setExpanded] = useState(true);
  const items = section.items.filter((item) => {
    if (!item.roles.includes(userRole)) return false;
    if (item.permissions && !item.permissions.some((p) => userPermissions.includes(p))) return false;
    return true;
  });

  if (items.length === 0) return null;

  return (
    <div className="mb-1">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center justify-between w-full px-4 py-2 text-[11px] font-semibold uppercase tracking-wider text-white/30 hover:text-white/50 transition"
      >
        {section.title}
        <ChevronDown
          size={12}
          className={`transition-transform duration-200 ${expanded ? "rotate-0" : "-rotate-90"}`}
        />
      </button>
      {expanded && (
        <div className="space-y-0.5">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2 rounded-lg text-sm transition mx-2 ${
                  isActive
                    ? "bg-orange-500/10 text-orange-400 font-medium"
                    : "text-white/50 hover:text-white/80 hover:bg-white/5"
                }`
              }
            >
              <item.icon size={16} strokeWidth={1.8} />
              {item.label}
            </NavLink>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Layout() {
  const { user, logout, hasPermission } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showSignOut, setShowSignOut] = useState(false);
  const userRole = user?.role ?? "";
  const canManageMedicines = hasPermission("manage_medicines");
  const userPermissions = user?.permissions ?? [];

  const totalNavItems = NAV_SECTIONS.reduce(
    (acc, section) => acc + section.items.filter((i) => {
      if (!i.roles.includes(userRole)) return false;
      if (i.permissions && !i.permissions.some((p) => userPermissions.includes(p))) return false;
      return true;
    }).length,
    0
  );

  return (
    <div className="h-screen bg-sand-50 flex overflow-hidden">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
          aria-hidden="true"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-ink-900 flex flex-col transform transition-transform duration-200 ease-out
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
        role="navigation"
        aria-label="Main navigation"
      >
        {/* Logo */}
        <div className="px-5 py-5 border-b border-white/10">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-orange-500 flex items-center justify-center">
              <Pill size={20} className="text-white" />
            </div>
            <div>
              <div className="font-display text-white text-lg tracking-tight leading-tight">Adom</div>
              <div className="text-orange-400/70 text-[10px] uppercase tracking-widest font-medium">Pharmacy</div>
            </div>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 space-y-1 overflow-y-auto">
          {NAV_SECTIONS.map((section) => (
            <SidebarSection key={section.title} section={section} userRole={userRole} userPermissions={userPermissions} />
          ))}
        </nav>

        {/* User Info */}
        <div className="px-4 py-4 border-t border-white/10">
          <div className="flex items-center gap-3 mb-3">
            <UserAvatar src={user?.profilePicture} name={user?.name ?? "U"} />
            <div className="min-w-0 flex-1">
              <div className="text-white text-sm font-medium truncate">{user?.name}</div>
              <div className="text-white/40 text-xs capitalize truncate">{user?.role.replace("_", " ")}</div>
            </div>
          </div>
          <button
            onClick={() => setShowSignOut(true)}
            className="flex items-center gap-2 text-white/40 hover:text-orange-400 text-xs w-full px-2 py-1.5 rounded-lg hover:bg-white/5 transition focus:outline-none focus:ring-2 focus:ring-orange-500/30"
          >
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 md:ml-64 h-screen">
        {/* Top Header */}
        <header className="hidden md:flex items-center justify-between px-6 py-3 bg-white border-b border-sand-200">
          <div className="flex items-center gap-4 flex-1 max-w-md">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
              <input
                type="text"
                placeholder="Search medicines, customers..."
                className="w-full pl-9 pr-4 py-2 rounded-lg bg-sand-50 border border-sand-200 text-sm outline-none focus:border-orange-400 focus:ring-2 focus:ring-orange-500/20 transition"
              />
              <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-ink-900/30 bg-sand-100 px-1.5 py-0.5 rounded font-mono">⌘K</kbd>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/pos"
              className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600 transition shadow-sm"
            >
              <ShoppingCart size={16} />
              POS
            </Link>
            {canManageMedicines && (
              <Link
                to="/medicines"
                className="flex items-center gap-2 px-4 py-2 bg-pine-600 text-white rounded-lg text-sm font-medium hover:bg-pine-700 transition shadow-sm"
              >
                <Plus size={16} />
                Add New
              </Link>
            )}

            <div className="w-px h-8 bg-sand-200 mx-1" />

            <button
              onClick={() => window.location.reload()}
              className="p-2 rounded-lg text-ink-900/40 hover:text-ink-900/70 hover:bg-sand-100 transition"
              aria-label="Refresh page"
            >
              <RefreshCw size={17} />
            </button>

            <NotificationBell />

            <div className="w-px h-8 bg-sand-200 mx-1" />

            <div className="flex items-center gap-3">
              <UserAvatar src={user?.profilePicture} name={user?.name ?? "U"} size="sm" />
              <div className="text-right">
                <div className="text-sm font-medium text-ink-900">{user?.name}</div>
                <div className="text-xs text-ink-900/40 capitalize">{user?.role.replace("_", " ")}</div>
              </div>
            </div>
          </div>
        </header>

        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between px-4 py-3 bg-white border-b border-sand-200">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-1 -ml-1 text-ink-900/60 hover:text-ink-900 focus:outline-none focus:ring-2 focus:ring-orange-500/30 rounded"
            aria-label="Open sidebar"
          >
            <Menu size={20} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-orange-500 flex items-center justify-center">
              <Pill size={14} className="text-white" />
            </div>
            <span className="font-display text-lg text-ink-900">Adom Pharmacy</span>
          </div>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <UserAvatar src={user?.profilePicture} name={user?.name ?? "U"} size="sm" />
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-24 md:pb-6">
          <Outlet />
        </main>

        {/* Mobile Bottom Nav */}
        <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t border-sand-200 flex justify-around py-2 safe-area-bottom" aria-label="Mobile navigation">
          {NAV_SECTIONS.flatMap((s) => s.items).filter((i) => i.roles.includes(userRole)).slice(0, 5).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex flex-col items-center gap-0.5 px-3 py-1 text-xs focus:outline-none focus:ring-2 focus:ring-orange-500/30 rounded ${
                  isActive ? "text-orange-500" : "text-ink-900/40"
                }`
              }
            >
              <item.icon size={19} strokeWidth={1.8} />
              <span className="truncate max-w-[4rem]">{item.label.split(" ")[0]}</span>
            </NavLink>
          ))}
        </nav>
      </div>

      {/* Sign Out Confirmation Dialog */}
      {showSignOut && createPortal(
        <div className="fixed inset-0 z-[300] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowSignOut(false)} />
          <div className="relative bg-white rounded-xl shadow-xl border border-sand-200 w-full max-w-sm mx-4 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center flex-shrink-0">
                <LogOut size={18} className="text-orange-500" />
              </div>
              <div>
                <h3 className="text-sm font-medium text-ink-900">Sign out</h3>
                <p className="text-xs text-ink-muted mt-0.5">Are you sure you want to sign out?</p>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowSignOut(false)}
                className="px-4 py-2 text-xs font-medium text-ink-900/60 hover:text-ink-900 bg-sand-100 hover:bg-sand-200 rounded-lg transition"
              >
                Cancel
              </button>
              <button
                onClick={logout}
                className="px-4 py-2 text-xs font-medium text-white bg-orange-500 hover:bg-orange-600 rounded-lg transition shadow-sm"
              >
                Sign out
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
