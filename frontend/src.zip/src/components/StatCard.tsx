import React from "react";
import { LucideIcon, AlertTriangle, Clock } from "lucide-react";

type CardVariant = "financial" | "alert" | "summary";

interface FinancialCardProps {
  variant: "financial";
  label: string;
  value: string;
  change?: string;
  changeDirection?: "up" | "down";
  action?: { label: string; onClick: () => void };
}

interface AlertCardProps {
  variant: "alert";
  label: string;
  value: string;
  description: string;
  severity: "warning" | "critical";
  action?: { label: string; onClick: () => void };
}

interface SummaryCardProps {
  variant: "summary";
  label: string;
  value: string;
}

type StatCardProps = FinancialCardProps | AlertCardProps | SummaryCardProps;

function FinancialCard({ label, value, change, changeDirection, action }: Omit<FinancialCardProps, "variant">) {
  return (
    <div className="bg-sand-25 rounded-lg p-5 shadow-card">
      <div className="font-semibold text-2xl text-ink-900 tabular-nums tracking-tight">
        {value}
      </div>
      <div className="text-xs text-ink-muted mt-1">{label}</div>
      {change && (
        <div className="mt-3 flex items-center gap-2">
          <span className={`text-xs font-medium ${changeDirection === "up" ? "text-pine-600" : "text-clay-500"}`}>
            {changeDirection === "up" ? "↑" : "↓"} {change}
          </span>
          <span className="text-xs text-ink-muted">vs last month</span>
        </div>
      )}
      {action && (
        <>
          <div className="border-t border-sand-100 mt-4 pt-3" />
          <button
            onClick={action.onClick}
            className="text-xs font-medium text-orange-500 hover:text-orange-600 transition-colors"
          >
            {action.label} →
          </button>
        </>
      )}
    </div>
  );
}

function AlertCard({ label, value, description, severity, action }: Omit<AlertCardProps, "variant">) {
  const borderColor = severity === "critical" ? "border-l-red-700" : "border-l-amber-600";
  const iconColor = severity === "critical" ? "text-red-700" : "text-amber-600";
  const Icon = severity === "critical" ? AlertTriangle : Clock;

  return (
    <div className={`bg-alert-card rounded-r-lg rounded-l-none border-l-4 ${borderColor} p-5`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon size={14} className={iconColor} />
        <span className="text-xs font-medium text-ink-800 uppercase tracking-wider">{label}</span>
      </div>
      <div className="font-semibold text-lg text-ink-900 tabular-nums">
        {value}
      </div>
      <div className="text-xs text-ink-muted mt-1">{description}</div>
      {action && (
        <button
          onClick={action.onClick}
          className="text-xs font-medium text-rust-600 hover:text-rust-700 transition-colors mt-3"
        >
          {action.label} →
        </button>
      )}
    </div>
  );
}

function SummaryCard({ label, value }: Omit<SummaryCardProps, "variant">) {
  return (
    <div className="bg-sand-25 rounded-lg p-5 shadow-card">
      <div className="font-semibold text-2xl text-ink-900 tabular-nums tracking-tight">
        {value}
      </div>
      <div className="text-xs text-ink-muted mt-1">{label}</div>
    </div>
  );
}

export default function StatCard(props: StatCardProps) {
  switch (props.variant) {
    case "financial":
      return <FinancialCard {...props} />;
    case "alert":
      return <AlertCard {...props} />;
    case "summary":
      return <SummaryCard {...props} />;
  }
}
