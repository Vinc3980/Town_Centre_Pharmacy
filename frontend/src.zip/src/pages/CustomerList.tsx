﻿import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search, Eye, Edit, Trash2, User } from "lucide-react";
import {
  fetchCustomers,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  Customer,
} from "../api/customers";
import Toast from "../components/ui/Toast";
import Modal from "../components/ui/Modal";
import { useAuth } from "../context/AuthContext";

interface FormData {
  name: string;
  phone: string;
  email: string;
  dateOfBirth: string;
  gender: "male" | "female" | "other" | "";
  bloodGroup: string;
  address: string;
  emergencyContact: string;
  emergencyPhone: string;
  allergies: string;
  medicalConditions: string;
  notes: string;
}

const initialFormData: FormData = {
  name: "",
  phone: "",
  email: "",
  dateOfBirth: "",
  gender: "",
  bloodGroup: "",
  address: "",
  emergencyContact: "",
  emergencyPhone: "",
  allergies: "",
  medicalConditions: "",
  notes: "",
};

const bloodGroups = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export default function CustomerList() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [toast, setToast] = useState<{
    message: string;
    type: "success" | "error";
  } | null>(null);

  const {
    data: customers = [],
    isLoading,
  } = useQuery({
    queryKey: ["customers", search],
    queryFn: () => fetchCustomers(search || undefined),
  });

  const createMutation = useMutation({
    mutationFn: createCustomer,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      setModalOpen(false);
      setFormData(initialFormData);
      setToast({ message: "Customer created successfully", type: "success" });
    },
    onError: () => {
      setToast({ message: "Failed to create customer", type: "error" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({
      id,
      payload,
    }: {
      id: string;
      payload: Record<string, unknown>;
    }) => updateCustomer(id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      setModalOpen(false);
      setEditingCustomer(null);
      setFormData(initialFormData);
      setToast({ message: "Customer updated successfully", type: "success" });
    },
    onError: () => {
      setToast({ message: "Failed to update customer", type: "error" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteCustomer,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      setToast({ message: "Customer deleted successfully", type: "success" });
    },
    onError: () => {
      setToast({ message: "Failed to delete customer", type: "error" });
    },
  });

  const handleOpenCreateModal = () => {
    setEditingCustomer(null);
    setFormData(initialFormData);
    setModalOpen(true);
  };

  const handleOpenEditModal = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData({
      name: customer.name,
      phone: customer.phone,
      email: customer.email || "",
      dateOfBirth: customer.dateOfBirth
        ? customer.dateOfBirth.substring(0, 10)
        : "",
      gender: customer.gender || "",
      bloodGroup: customer.bloodGroup || "",
      address: customer.address || "",
      emergencyContact: customer.emergencyContact || "",
      emergencyPhone: customer.emergencyPhone || "",
      allergies: (customer.allergies || []).join(", "),
      medicalConditions: (customer.medicalConditions || []).join(", "),
      notes: customer.notes || "",
    });
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
    setEditingCustomer(null);
    setFormData(initialFormData);
  };

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const payload: Record<string, unknown> = {
      name: formData.name,
      phone: formData.phone,
      email: formData.email || undefined,
      dateOfBirth: formData.dateOfBirth || undefined,
      gender: formData.gender || undefined,
      bloodGroup: formData.bloodGroup || undefined,
      address: formData.address || undefined,
      emergencyContact: formData.emergencyContact || undefined,
      emergencyPhone: formData.emergencyPhone || undefined,
      allergies: formData.allergies
        ? formData.allergies
            .split(",")
            .map((a) => a.trim())
            .filter(Boolean)
        : [],
      medicalConditions: formData.medicalConditions
        ? formData.medicalConditions
            .split(",")
            .map((c) => c.trim())
            .filter(Boolean)
        : [],
      notes: formData.notes || undefined,
    };

    if (editingCustomer) {
      updateMutation.mutate({ id: editingCustomer._id, payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleDelete = (customer: Customer) => {
    if (
      window.confirm(
        `Are you sure you want to delete "${customer.name}"? This action cannot be undone.`
      )
    ) {
      deleteMutation.mutate(customer._id);
    }
  };

  const isSubmitting = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="min-h-screen bg-sand-50 p-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="font-display text-2xl font-bold text-ink-900">
            Customers
          </h1>
          <button
            onClick={handleOpenCreateModal}
            className="flex items-center gap-2 rounded-lg bg-pine-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-pine-800"
          >
            <Plus size={16} />
            Add customer
          </button>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-clay-600"
            />
            <input
              type="text"
              placeholder="Search by name, phone, or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-sand-200 bg-white py-2 pl-10 pr-4 text-sm text-ink-900 placeholder-clay-600 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
            />
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-sand-200 bg-white">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-sand-200 bg-sand-100">
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Name
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Phone
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Email
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Gender
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Blood Group
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Outstanding Balance
                  </th>
                  <th className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-4 py-8 text-center text-clay-600"
                    >
                      Loading customers...
                    </td>
                  </tr>
                ) : customers.length === 0 ? (
                  <tr>
                    <td
                      colSpan={8}
                      className="px-4 py-8 text-center text-clay-600"
                    >
                      No customers found.
                    </td>
                  </tr>
                ) : (
                  customers.map((customer) => (
                    <tr
                      key={customer._id}
                      className="border-b border-sand-200 last:border-0 hover:bg-sand-50"
                    >
                      <td className="px-4 py-3">
                        {customer.profileImage ? (
                          <img
                            src={customer.profileImage}
                            alt={customer.name}
                            className="h-8 w-8 rounded-full object-cover"
                          />
                        ) : (
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sand-100">
                            <User size={14} className="text-clay-600" />
                          </div>
                        )}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 font-medium text-ink-900">
                        {customer.name}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-ink-900">
                        {customer.phone}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-ink-900">
                        {customer.email || "-"}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-ink-900">
                        {customer.gender
                          ? customer.gender.charAt(0).toUpperCase() +
                            customer.gender.slice(1)
                          : "-"}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-ink-900">
                        {customer.bloodGroup || "-"}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3">
                        <span
                          className={
                            customer.outstandingBalance > 0
                              ? "font-medium text-clay-600"
                              : "text-ink-900"
                          }
                        >
                          {customer.outstandingBalance.toFixed(2)}
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() =>
                              navigate(`/customers/${customer._id}`)
                            }
                            className="rounded-lg p-1.5 text-pine-700 transition-colors hover:bg-pine-50"
                            title="View"
                          >
                            <Eye size={16} />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(customer)}
                            className="rounded-lg p-1.5 text-pine-700 transition-colors hover:bg-pine-50"
                            title="Edit"
                          >
                            <Edit size={16} />
                          </button>
                          <button
                            onClick={() => handleDelete(customer)}
                            disabled={deleteMutation.isPending}
                            className="rounded-lg p-1.5 text-clay-600 transition-colors hover:bg-clay-50 disabled:opacity-50"
                            title="Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <Modal
        open={modalOpen}
        onClose={handleCloseModal}
        title={editingCustomer ? "Edit Customer" : "Add Customer"}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Name <span className="text-clay-600">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Phone <span className="text-clay-600">*</span>
              </label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Date of Birth
              </label>
              <input
                type="date"
                name="dateOfBirth"
                value={formData.dateOfBirth}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Gender
              </label>
              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              >
                <option value="">Select gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Blood Group
              </label>
              <select
                name="bloodGroup"
                value={formData.bloodGroup}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              >
                <option value="">Select blood group</option>
                {bloodGroups.map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-ink-900">
              Address
            </label>
            <textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
              rows={2}
              className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Emergency Contact
              </label>
              <input
                type="text"
                name="emergencyContact"
                value={formData.emergencyContact}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-ink-900">
                Emergency Phone
              </label>
              <input
                type="text"
                name="emergencyPhone"
                value={formData.emergencyPhone}
                onChange={handleChange}
                className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-ink-900">
              Allergies
            </label>
            <input
              type="text"
              name="allergies"
              value={formData.allergies}
              onChange={handleChange}
              placeholder="e.g. Penicillin, Aspirin, Shellfish"
              className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 placeholder-clay-600 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
            />
            <p className="mt-1 text-xs text-clay-600">
              Comma-separated list
            </p>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-ink-900">
              Medical Conditions
            </label>
            <input
              type="text"
              name="medicalConditions"
              value={formData.medicalConditions}
              onChange={handleChange}
              placeholder="e.g. Diabetes, Hypertension, Asthma"
              className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 placeholder-clay-600 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
            />
            <p className="mt-1 text-xs text-clay-600">
              Comma-separated list
            </p>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-ink-900">
              Notes
            </label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={3}
              className="w-full rounded-lg border border-sand-200 px-3 py-2 text-sm text-ink-900 focus:border-pine-700 focus:outline-none focus:ring-1 focus:ring-pine-700"
            />
          </div>

          <div className="flex justify-end gap-3 border-t border-sand-200 pt-4">
            <button
              type="button"
              onClick={handleCloseModal}
              className="rounded-lg border border-sand-200 px-4 py-2 text-sm font-medium text-ink-900 transition-colors hover:bg-sand-100"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="rounded-lg bg-pine-700 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-pine-800 disabled:opacity-50"
            >
              {isSubmitting
                ? "Saving..."
                : editingCustomer
                  ? "Update Customer"
                  : "Create Customer"}
            </button>
          </div>
        </form>
      </Modal>

      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}
    </div>
  );
}
