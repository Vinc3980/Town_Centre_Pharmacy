import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "../context/AuthContext";
import { Lock, Mail, Loader2, Eye, EyeOff, User, Pill } from "lucide-react";

const loginSchema = z.object({
  email: z.string().min(1, "Email or Staff ID is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [serverError, setServerError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(data: LoginForm) {
    setServerError("");
    try {
      await login(data.email, data.password);
      navigate("/");
    } catch {
      setServerError("That email or password doesn't match our records.");
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center">
              <Pill size={22} className="text-white" />
            </div>
            <div>
              <div className="font-display text-xl text-ink-900 leading-tight">Adom</div>
              <div className="text-orange-500/70 text-[10px] uppercase tracking-widest font-medium">Pharmacy</div>
            </div>
          </div>

          {/* Header */}
          <div className="mb-8">
            <h1 className="font-display text-2xl font-bold text-ink-900 mb-2">Sign In</h1>
            <p className="text-sm text-ink-900/50">
              Access the Adom Pharmacy panel using your email and passcode.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
            <div>
              <label htmlFor="email" className="text-xs font-medium text-ink-900/60 block mb-1.5">
                Email <span className="text-clay-500">*</span>
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
                <input
                  id="email"
                  type="text"
                  autoComplete="username"
                  aria-invalid={!!errors.email}
                  placeholder="e.g. admin@adompharmacy.gh or ST-0001"
                  {...register("email")}
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border text-sm outline-none transition border-sand-200 focus:border-orange-400 focus:ring-2 focus:ring-orange-500/20"
                />
              </div>
              {errors.email && <p className="text-xs text-red-600 mt-1" role="alert">{errors.email.message}</p>}
            </div>

            <div>
              <label htmlFor="password" className="text-xs font-medium text-ink-900/60 block mb-1.5">
                Password <span className="text-clay-500">*</span>
              </label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  aria-invalid={!!errors.password}
                  {...register("password")}
                  className="w-full pl-10 pr-10 py-2.5 rounded-lg border text-sm outline-none transition border-sand-200 focus:border-orange-400 focus:ring-2 focus:ring-orange-500/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-900/30 hover:text-ink-900/60 focus:outline-none"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-red-600 mt-1" role="alert">{errors.password.message}</p>}
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-ink-900/60 cursor-pointer">
                <input
                  type="checkbox"
                  className="rounded border-sand-300 text-orange-500 focus:ring-orange-500"
                />
                Remember Me
              </label>
              <Link to="/forgot-password" className="text-sm text-orange-500 hover:text-orange-600 font-medium transition">
                Forgot Password?
              </Link>
            </div>

            {serverError && (
              <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700" role="alert">
                {serverError}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-lg bg-orange-500 text-white text-sm font-semibold hover:bg-orange-600 transition disabled:opacity-50 flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-orange-500/30 shadow-sm"
            >
              {isSubmitting ? <><Loader2 size={16} className="animate-spin" /> Signing in…</> : "Sign In"}
            </button>

            <p className="text-xs text-ink-900/35 text-center pt-1">
              Demo: admin@adompharmacy.gh / Admin123! or use Staff ID
            </p>
          </form>

          <p className="text-[10px] text-ink-900/25 text-center mt-8">
            Copyright © 2025 · AdomPharmacy
          </p>
        </div>
      </div>

      {/* Right Side - Illustration */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-100 via-orange-50 to-orange-200" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="w-64 h-64 rounded-full bg-orange-200/50 mx-auto mb-8 flex items-center justify-center">
              <Pill size={80} className="text-orange-400/60" />
            </div>
            <div className="font-display text-3xl text-orange-800/40 mb-2">Adom Pharmacy</div>
            <div className="text-sm text-orange-600/40">Inventory Management System</div>
          </div>
        </div>
      </div>
    </div>
  );
}
