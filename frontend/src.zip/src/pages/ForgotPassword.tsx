import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Mail, CheckCircle, Pill } from "lucide-react";
import { requestPasswordReset } from "../api/users";
import Button from "../components/ui/Button";
import Input from "../components/ui/Input";
import Toast from "../components/ui/Toast";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      await requestPasswordReset(email);
      setSent(true);
    } catch (err) {
      setToast({ message: (err as { response?: { data?: { message?: string } } }).response?.data?.message || "Something went wrong", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center">
              <Pill size={22} className="text-white" />
            </div>
            <div>
              <div className="font-display text-xl text-ink-900 leading-tight">Adom</div>
              <div className="text-orange-500/70 text-[10px] uppercase tracking-widest font-medium">Pharmacy</div>
            </div>
          </div>

          {sent ? (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-pine-50 flex items-center justify-center mx-auto">
                <CheckCircle size={32} className="text-pine-600" />
              </div>
              <h1 className="font-display text-2xl font-bold text-ink-900">Request Sent</h1>
              <p className="text-ink-900/50 text-sm">
                If your email is registered, the admin has been notified and will review your password reset request.
              </p>
              <Link to="/login" className="inline-block mt-4">
                <Button variant="secondary">Return to Login</Button>
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-8">
                <h1 className="font-display text-2xl font-bold text-ink-900 mb-2">Forgot password?</h1>
                <p className="text-sm text-ink-900/50">
                  If you forgot your password, well, then we'll email you instructions to reset your password.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <Input
                  label="Email Address"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. john@adompharmacy.gh"
                  required
                />
                <Button type="submit" loading={loading} className="w-full">
                  Submit
                </Button>
              </form>

              <Link to="/login" className="inline-block mt-4 text-sm text-orange-500 hover:text-orange-600 font-medium">
                Return to Login
              </Link>
            </>
          )}
        </div>
      </div>

      {/* Right Side - Illustration */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-100 via-orange-50 to-orange-200" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className="w-64 h-64 rounded-full bg-orange-200/50 mx-auto mb-8 flex items-center justify-center">
              <Mail size={80} className="text-orange-400/60" />
            </div>
            <div className="font-display text-3xl text-orange-800/40 mb-2">Adom Pharmacy</div>
            <div className="text-sm text-orange-600/40">Password Recovery</div>
          </div>
        </div>
      </div>

      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
}
