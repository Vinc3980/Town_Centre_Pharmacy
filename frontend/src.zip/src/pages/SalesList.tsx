import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { listSales } from "../api/sales";
import { SaleDetail } from "../types";
import SearchInput from "../components/ui/SearchInput";
import Select from "../components/ui/Select";
import Badge from "../components/ui/Badge";
import { TableSkeleton } from "../components/ui/Skeleton";
import EmptyState from "../components/ui/EmptyState";
import { Receipt } from "lucide-react";

function ghs(n: number) {
  return "GHS " + n.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

const STATUS_OPTIONS = [
  { value: "", label: "All statuses" },
  { value: "completed", label: "Completed" },
  { value: "partially_refunded", label: "Partially refunded" },
  { value: "refunded", label: "Refunded" },
  { value: "voided", label: "Voided" },
  { value: "held", label: "Held" },
];

const STATUS_BADGE: Record<string, string> = {
  completed: "pine",
  partially_refunded: "amber",
  refunded: "red",
  voided: "red",
  held: "sand",
};

export default function SalesList() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const { data: sales, isLoading } = useQuery({
    queryKey: ["sales-list", search, status, from, to],
    queryFn: () => listSales({ search: search || undefined, status: status || undefined, from: from || undefined, to: to || undefined }),
  });

  return (
    <div className="space-y-4">
      <h1 className="text-lg font-display text-ink-900">Sales</h1>

      <div className="bg-sand-25 rounded-xl shadow-card p-4">
        <div className="flex flex-wrap gap-3">
          <div className="flex-1 min-w-[200px]">
            <SearchInput
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by transaction #"
            />
          </div>
          <Select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            options={STATUS_OPTIONS}
          />
          <input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            aria-label="From date"
            className="px-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
          />
          <input
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            aria-label="To date"
            className="px-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
          />
        </div>
      </div>

      <div className="bg-sand-25 rounded-xl shadow-card overflow-hidden">
        {isLoading ? (
          <TableSkeleton rows={5} cols={6} />
        ) : !sales || sales.length === 0 ? (
          <EmptyState
            icon={<Receipt size={24} className="text-ink-900/30" />}
            title="No sales found"
            description="Sales will appear here once transactions are processed."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm" role="table">
              <thead>
                <tr className="border-b border-sand-200 text-ink-900/50 text-left">
                  <th className="px-4 py-3 font-medium" scope="col">Transaction</th>
                  <th className="px-4 py-3 font-medium hidden sm:table-cell" scope="col">Date</th>
                  <th className="px-4 py-3 font-medium hidden md:table-cell" scope="col">Cashier</th>
                  <th className="px-4 py-3 font-medium hidden lg:table-cell" scope="col">Items</th>
                  <th className="px-4 py-3 font-medium text-right" scope="col">Total</th>
                  <th className="px-4 py-3 font-medium" scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
                {sales.map((s: SaleDetail) => (
                  <tr
                    key={s._id}
                    onClick={() => navigate(`/sales/${s._id}`)}
                    className="border-b border-sand-100 last:border-0 hover:bg-sand-50 cursor-pointer transition focus:outline-none focus:ring-2 focus:ring-inset focus:ring-pine-500/30"
                    tabIndex={0}
                    role="row"
                    onKeyDown={(e) => { if (e.key === "Enter") navigate(`/sales/${s._id}`); }}
                  >
                    <td className="px-4 py-3 font-medium text-ink-900">{s.transactionNumber}</td>
                    <td className="px-4 py-3 text-ink-900/60 hidden sm:table-cell">{new Date(s.createdAt).toLocaleDateString()}</td>
                    <td className="px-4 py-3 text-ink-900/60 hidden md:table-cell">{typeof s.cashier === "object" ? s.cashier.name : ""}</td>
                    <td className="px-4 py-3 text-ink-900/60 hidden lg:table-cell">{s.items.length}</td>
                    <td className="px-4 py-3 text-right font-medium text-ink-900 tabular-nums">{ghs(s.total)}</td>
                    <td className="px-4 py-3">
                      <Badge variant={STATUS_BADGE[s.status] ?? "sand"}>
                        {s.status.replace(/_/g, " ")}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
