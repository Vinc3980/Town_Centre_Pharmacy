import React, { useEffect, useState, useMemo, useRef } from "react";
import { Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import {
  Wallet, TrendingUp, Users, AlertTriangle, CircleDot,
  Package, Clock, ArrowDownRight, ArrowUpRight, CreditCard,
  Smartphone, Building2, CircleDollarSign, ShoppingCart,
  RotateCcw, ClipboardList, Activity, FileText, TrendingDown,
  Calendar, ChevronRight, ChevronDown, Eye, PackageCheck, Undo2,
  DollarSign, BarChart3, Receipt,
} from "lucide-react";
import {
  fetchDashboardSummary, fetchRevenueTrend, fetchPaymentBreakdown,
  fetchTopMedicines, fetchSalesByCategory, fetchInventoryAlerts,
  fetchStaffDashboard, syncInventoryAlerts,
} from "../api/dashboard";
import { getSocket } from "../lib/socket";
import { useAuth } from "../context/AuthContext";
import Toast from "../components/ui/Toast";
import StatCard from "../components/StatCard";
import StaffPerformancePanel from "../components/StaffPerformancePanel";

function ghs(n: number) {
  return "GHS " + n.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

interface FeedEvent { id: string; text: string; time: string }

const PAYMENT_COLORS: Record<string, string> = {
  cash: "#137056",
  mobile_money: "#3b82f6",
  card: "#8b5cf6",
  bank_transfer: "#f59e0b",
  other: "#6b7280",
};

const CATEGORY_COLORS = ["#F97316", "#137056", "#3b82f6", "#8b5cf6", "#f59e0b", "#ef4444", "#10b981", "#6366f1"];

const MANAGER_ROLES = ["branch_manager", "admin"];

function formatDateRange(days: number) {
  const end = new Date();
  const start = new Date();
  start.setDate(start.getDate() - days);
  const fmt = (d: Date) => d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  return `${fmt(start)} - ${fmt(end)}`;
}

/* ─── Staff Dashboard ─── */
function StaffDashboardView({ userName, role }: { userName: string; role: string }) {
  const { data: staff, isLoading } = useQuery({
    queryKey: ["staff-dashboard"],
    queryFn: fetchStaffDashboard,
    refetchInterval: 15000,
  });
  const { data: alerts } = useQuery({ queryKey: ["inventory-alerts"], queryFn: fetchInventoryAlerts });
  const [loginToast, setLoginToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  const alertsShownRef = useRef(false);

  useEffect(() => {
    if (!alerts || alertsShownRef.current) return;
    alertsShownRef.current = true;
    syncInventoryAlerts().catch(() => {});
    if (alerts.expired.length > 0) {
      setLoginToast({ message: `${alerts.expired.length} expired product(s) in stock — please remove them`, type: "error" });
    } else if (alerts.lowStock.length > 0) {
      setLoginToast({ message: `${alerts.lowStock.length} product(s) below reorder level`, type: "info" });
    }
  }, [alerts]);

  if (isLoading) return <p className="text-sm text-ink-900/40">Loading dashboard…</p>;

  return (
    <div className="space-y-4">
      {/* Welcome Banner */}
      <div className="bg-sand-25 rounded-lg p-4 shadow-card">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl text-ink-900">Welcome, {userName}</h1>
            <p className="text-sm text-ink-muted mt-1">Here's what's happening with your store today.</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-ink-muted bg-sand-75 px-3 py-1.5 rounded-lg">
            <Calendar size={14} />
            {new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
          </div>
        </div>
      </div>

      {/* Primary Metric — Today's Sales */}
      <div className="bg-sand-25 rounded-xl p-5 shadow-card-hover">
        <div className="text-xs text-ink-muted mb-2">Today's Sales</div>
        <div className="font-sans font-semibold text-3xl text-ink-900 tabular-nums tracking-tight">{ghs(staff?.todaySales ?? 0)}</div>
      </div>

      {/* Secondary Metrics — compact recessed strip */}
      <div className="bg-sand-75 rounded-xl p-3 grid grid-cols-3 gap-3">
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Transactions</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{staff?.todayTransactions ?? 0}</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Cash Sales</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{ghs(staff?.todayCashSales ?? 0)}</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Pending Refunds</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{staff?.pendingRefunds ?? 0}</div>
        </div>
      </div>

      {/* Session Status */}
      {staff?.currentSession && (
        <div className="bg-sand-25 rounded-lg p-4 shadow-card">
          <h2 className="text-xs text-ink-muted mb-2">Current Session</h2>
          <div className="flex items-center gap-6 text-sm">
            <div>
              <span className="text-ink-900/40">Opening Cash: </span>
              <span className="font-medium">{ghs(staff.currentSession.openingCash)}</span>
            </div>
            <div>
              <span className="text-ink-900/40">Status: </span>
              <span className={`font-medium ${staff.currentSession.status === "open" ? "text-pine-600" : "text-ink-900/60"}`}>
                {staff.currentSession.status}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <Link to="/pos" className="bg-sand-25 rounded-lg p-4 hover:shadow-card-hover transition-all flex items-center gap-3 shadow-card">
          <ShoppingCart size={18} className="text-ink-800" strokeWidth={1.5} />
          <div>
            <div className="text-sm font-medium text-ink-900">Point of Sale</div>
            <div className="text-xs text-ink-muted">Start selling</div>
          </div>
          <ChevronRight size={16} className="ml-auto text-ink-muted" />
        </Link>
        <Link to="/activity" className="bg-sand-25 rounded-lg p-4 hover:shadow-card-hover transition-all flex items-center gap-3 shadow-card">
          <ClipboardList size={18} className="text-ink-800" strokeWidth={1.5} />
          <div>
            <div className="text-sm font-medium text-ink-900">My Activity</div>
            <div className="text-xs text-ink-muted">View your history</div>
          </div>
          <ChevronRight size={16} className="ml-auto text-ink-muted" />
        </Link>
        <Link to="/daily-session" className="bg-sand-25 rounded-lg p-4 hover:shadow-card-hover transition-all flex items-center gap-3 shadow-card">
          <Clock size={18} className="text-ink-800" strokeWidth={1.5} />
          <div>
            <div className="text-sm font-medium text-ink-900">Daily Session</div>
            <div className="text-xs text-ink-muted">Open or close session</div>
          </div>
          <ChevronRight size={16} className="ml-auto text-ink-muted" />
        </Link>
      </div>

      {/* Inventory Alerts */}
      {["staff"].includes(role) && alerts && (alerts.lowStock.length > 0 || alerts.expiringSoon.length > 0) && (
        <div className="grid lg:grid-cols-2 gap-4">
          {alerts.lowStock.length > 0 && (
            <StatCard
              variant="alert"
              label="Low Stock"
              value={`${alerts.lowStock.length} products`}
              description="below reorder level"
              severity="warning"
              action={{ label: "View Inventory Alerts", onClick: () => window.location.href = "/inventory-alerts" }}
            />
          )}
          {alerts.expiringSoon.length > 0 && (
            <StatCard
              variant="alert"
              label="Expiring Soon"
              value={`${alerts.expiringSoon.length} batches`}
              description="within 30 days"
              severity="critical"
              action={{ label: "View Inventory Alerts", onClick: () => window.location.href = "/inventory-alerts" }}
            />
          )}
        </div>
      )}
      {loginToast && (
        <Toast message={loginToast.message} type={loginToast.type} onClose={() => setLoginToast(null)} duration={5000} />
      )}
    </div>
  );
}

/* ─── Owner / Manager Dashboard ─── */
function ManagerDashboardView() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [feed, setFeed] = useState<FeedEvent[]>([]);
  const [days, setDays] = useState(7);
  const [loginToast, setLoginToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  const alertsShownRef = useRef(false);

  const { data: summary } = useQuery({
    queryKey: ["dashboard-summary", days],
    queryFn: () => fetchDashboardSummary({ days }),
    refetchInterval: 15000,
  });
  const { data: trend } = useQuery({
    queryKey: ["revenue-trend", days],
    queryFn: () => fetchRevenueTrend({ days }),
  });
  const { data: payments } = useQuery({ queryKey: ["payment-breakdown", days], queryFn: () => fetchPaymentBreakdown({ days }) });
  const { data: topMeds } = useQuery({ queryKey: ["top-medicines", days], queryFn: () => fetchTopMedicines({ days, limit: 8 }) });
  const { data: categories } = useQuery({ queryKey: ["sales-by-category", days], queryFn: () => fetchSalesByCategory({ days }) });
  const { data: alerts } = useQuery({ queryKey: ["inventory-alerts"], queryFn: fetchInventoryAlerts });

  useEffect(() => {
    if (!alerts || alertsShownRef.current) return;
    alertsShownRef.current = true;
    syncInventoryAlerts().catch(() => {});
    if (alerts.expired.length > 0) {
      setLoginToast({ message: `${alerts.expired.length} expired product(s) in stock — please remove them`, type: "error" });
    } else if (alerts.lowStock.length > 0) {
      setLoginToast({ message: `${alerts.lowStock.length} product(s) below reorder level`, type: "info" });
    }
  }, [alerts]);

  const pieData = useMemo(() => {
    if (!payments) return [];
    return payments.map((p) => ({ name: p.method.replace("_", " "), value: p.total, count: p.count }));
  }, [payments]);

  const barData = useMemo(() => {
    if (!topMeds) return [];
    return topMeds.map((m) => ({ name: m.name.length > 14 ? m.name.slice(0, 14) + "…" : m.name, quantity: m.totalQuantity, revenue: m.totalRevenue }));
  }, [topMeds]);

  const catBarData = useMemo(() => {
    if (!categories) return [];
    return categories.map((c) => ({ name: c.category, revenue: c.totalRevenue, quantity: c.totalQuantity }));
  }, [categories]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;

    function pushEvent(text: string) {
      setFeed((f) => [{ id: Math.random().toString(36).slice(2), text, time: new Date().toLocaleTimeString() }, ...f].slice(0, 20));
      queryClient.invalidateQueries({ queryKey: ["dashboard-summary"] });
      queryClient.invalidateQueries({ queryKey: ["revenue-trend"] });
    }

    socket.on("sale.created", (s: { cashierName: string; total: number; items: { quantity: number; name: string }[] }) => {
      pushEvent(`${s.cashierName} sold ${s.items.map((i) => `${i.quantity} x ${i.name}`).join(", ")} — ${ghs(s.total)}`);
    });
    socket.on("sale.refunded", (s: { transactionNumber: string; total: number }) => {
      pushEvent(`Refund processed #${s.transactionNumber} — ${ghs(s.total)}`);
    });
    socket.on("stock.low", (n: { message: string }) => pushEvent(n.message));
    socket.on("staff.login", (s: { name: string }) => pushEvent(`${s.name} logged in`));
    socket.on("notification.created", () => queryClient.invalidateQueries({ queryKey: ["inventory-alerts"] }));

    return () => {
      socket.off("sale.created");
      socket.off("sale.refunded");
      socket.off("stock.low");
      socket.off("staff.login");
      socket.off("notification.created");
    };
  }, [queryClient]);

  if (!summary) return <p className="text-sm text-ink-900/40">Loading dashboard…</p>;

  return (
    <div className="space-y-4">
      {/* Welcome Banner */}
      <div className="bg-sand-25 rounded-lg p-4 shadow-card">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl text-ink-900">Welcome, {user?.name ?? "Admin"}</h1>
            <p className="text-sm text-ink-muted mt-1">You have <span className="font-medium text-ink-900">{summary.transactionCount}+ Orders</span> Today</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-ink-muted bg-sand-75 px-3 py-1.5 rounded-lg">
            <Calendar size={14} />
            {formatDateRange(days)}
          </div>
        </div>
      </div>

      {/* Low Stock Alert Banner */}
      {alerts && alerts.lowStock.length > 0 && (
        <div className="bg-alert-card rounded-lg border-l-4 border-l-amber-600 p-3 flex items-center gap-3">
          <AlertTriangle size={16} className="text-amber-600 flex-shrink-0" />
          <p className="text-sm text-amber-800">
            <span className="font-medium">{alerts.lowStock[0].name}</span> is running low — below {alerts.lowStock[0].reorderLevel} pcs.
            {" "}
            <Link to="/inventory-alerts" className="font-semibold text-orange-600 hover:underline">Add Stock</Link>
          </p>
          {alerts.lowStock.length > 1 && (
            <span className="text-xs text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full ml-auto flex-shrink-0">
              +{alerts.lowStock.length - 1} more
            </span>
          )}
        </div>
      )}

      {/* Time Period Selector */}
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium text-ink-800">Overview</div>
        <div className="flex gap-1">
          {([7, 14, 30, 90] as const).map((d) => (
            <button
              key={d}
              onClick={() => setDays(d)}
              className={`px-2.5 py-1 rounded text-xs font-medium transition ${
                days === d
                  ? "bg-orange-500 text-white shadow-sm"
                  : "bg-sand-75 text-ink-muted hover:bg-sand-100"
              }`}
            >
              {d}d
            </button>
          ))}
        </div>
      </div>

      {/* Primary Metrics — Total Sales & Net Profit (large, prominent) */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-sand-25 rounded-xl p-5 shadow-card-hover">
          <div className="text-xs text-ink-muted mb-2">Total Sales</div>
          <div className="font-sans font-semibold text-3xl text-ink-900 tabular-nums tracking-tight">{ghs(summary.totalRevenue)}</div>
          <div className="mt-2 flex items-center gap-1.5">
            <span className="text-xs font-medium text-pine-600">↑ +22%</span>
            <span className="text-xs text-ink-muted">vs last month</span>
          </div>
        </div>
        <div className="bg-sand-25 rounded-xl p-5 shadow-card-hover">
          <div className="text-xs text-ink-muted mb-2">Net Profit</div>
          <div className={`font-sans font-semibold text-3xl tabular-nums tracking-tight ${summary.netProfit >= 0 ? "text-ink-900" : "text-red-700"}`}>{ghs(summary.netProfit)}</div>
          <div className="mt-2 flex items-center gap-1.5">
            <span className={`text-xs font-medium ${summary.netProfit >= 0 ? "text-pine-600" : "text-red-700"}`}>
              {summary.netProfit >= 0 ? "↑" : "↓"} {summary.netProfit >= 0 ? "+" : ""}{summary.totalRevenue > 0 ? Math.round((summary.netProfit / summary.totalRevenue) * 100) : 0}%
            </span>
            <span className="text-xs text-ink-muted">margin</span>
          </div>
        </div>
      </div>

      {/* Secondary Metrics — compact recessed strip */}
      <div className="bg-sand-75 rounded-xl p-3 grid grid-cols-4 gap-3">
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Sales Return</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{ghs(summary.totalDiscount)}</div>
          <div className="text-[10px] text-red-700 mt-0.5">↓ 19%</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Total Purchase</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{ghs(summary.totalExpenses)}</div>
          <div className="text-[10px] text-pine-600 mt-0.5">↑ 41%</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Purchase Return</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{ghs(summary.totalDiscount)}</div>
          <div className="text-[10px] text-red-700 mt-0.5">↓ 20%</div>
        </div>
        <div className="text-center">
          <div className="text-[10px] text-ink-muted">Invoice Due</div>
          <div className="font-sans font-semibold text-base text-ink-900 tabular-nums mt-0.5">{ghs(summary.bankTransferTotal)}</div>
        </div>
      </div>

      {/* Charts + Overall Information — recessed panel behind foreground cards */}
      <div className="bg-sand-75 rounded-xl p-4 space-y-4">
        {/* Chart row */}
        <div className="grid lg:grid-cols-3 gap-4">
          {/* Sales & Purchase Chart */}
          <div className="lg:col-span-2 bg-sand-25 rounded-lg p-4 shadow-card">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-medium text-ink-800">Sales & Purchase</h2>
              <div className="flex gap-1">
                {(["1D", "1W", "1M", "3M", "6M", "1Y"] as const).map((p) => (
                  <button
                    key={p}
                    className={`px-2 py-0.5 rounded text-[10px] font-medium transition ${
                      p === "1Y" ? "bg-orange-500 text-white" : "text-ink-muted hover:bg-sand-100"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-4 mb-3">
              <div className="flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-orange-400" />
                <span className="text-ink-muted">Purchase</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-pine-600" />
                <span className="text-ink-muted">Sales</span>
              </div>
            </div>
            <div style={{ height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={trend ?? []} barGap={2}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E6E3D6" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#99958A" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: "#99958A" }} axisLine={false} tickLine={false} width={50} />
                  <Tooltip formatter={(v: number) => ghs(v)} />
                  <Bar dataKey="revenue" name="Sales" fill="#137056" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="profit" name="Purchase" fill="#F97316" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Overall Information — compact list */}
          <div className="bg-sand-25 rounded-lg p-4 shadow-card">
            <h2 className="text-sm font-medium text-ink-800 mb-3">Overall Information</h2>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Package size={16} className="text-ink-800" strokeWidth={1.5} />
                  <span className="text-xs text-ink-muted">Suppliers</span>
                </div>
                <span className="font-sans font-semibold text-sm text-ink-900 tabular-nums">{summary.lowStockCount}</span>
              </div>
              <div className="border-t border-sand-100" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Users size={16} className="text-ink-800" strokeWidth={1.5} />
                  <span className="text-xs text-ink-muted">Customers</span>
                </div>
                <span className="font-sans font-semibold text-sm text-ink-900 tabular-nums">{summary.transactionCount}</span>
              </div>
              <div className="border-t border-sand-100" />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <ClipboardList size={16} className="text-ink-800" strokeWidth={1.5} />
                  <span className="text-xs text-ink-muted">Orders</span>
                </div>
                <span className="font-sans font-semibold text-sm text-ink-900 tabular-nums">{summary.transactionCount}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lower Row: Customers + Top Selling + Low Stock */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Customers Overview */}
        <div className="bg-sand-25 rounded-lg p-4 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-ink-800">Customers Overview</h2>
            <button className="text-xs text-ink-muted hover:text-ink-800">Today</button>
          </div>
          <div className="flex items-center gap-5">
            <div style={{ width: 100, height: 100 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[
                      { name: "First Time", value: 55, fill: "#F97316" },
                      { name: "Returning", value: 45, fill: "#137056" },
                    ]}
                    cx="50%"
                    cy="50%"
                    innerRadius={30}
                    outerRadius={45}
                    dataKey="value"
                    paddingAngle={3}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2.5">
              <div>
                <div className="font-sans font-semibold text-lg text-ink-900 tabular-nums">5.5K</div>
                <div className="text-[10px] text-ink-muted">First Time</div>
                <span className="text-[10px] text-pine-600 bg-pine-50 px-1.5 py-0.5 rounded-full">+25%</span>
              </div>
              <div>
                <div className="font-sans font-semibold text-lg text-ink-900 tabular-nums">3.5K</div>
                <div className="text-[10px] text-ink-muted">Return</div>
                <span className="text-[10px] text-pine-600 bg-pine-50 px-1.5 py-0.5 rounded-full">+21%</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top Selling Products — table/list */}
        <div className="bg-sand-25 rounded-lg p-4 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-ink-800">Top Selling Products</h2>
            <button className="text-xs text-ink-muted hover:text-ink-800 flex items-center gap-1">
              Today <ChevronDown size={12} />
            </button>
          </div>
          <div>
            {barData.slice(0, 5).map((item, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-sand-100 last:border-0">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-[10px] text-ink-muted w-4 text-right flex-shrink-0">{i + 1}</span>
                  <span className="text-xs font-medium text-ink-900 truncate">{item.name}</span>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="text-[10px] text-ink-muted">{item.quantity} sold</span>
                  <span className="text-xs text-ink-900 tabular-nums font-medium">{ghs(item.revenue)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low Stock Products — alert card treatment */}
        <div className="bg-alert-card rounded-lg border-l-4 border-l-amber-600 p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-ink-800 flex items-center gap-2">
              <AlertTriangle size={14} className="text-amber-600" /> Low Stock
            </h2>
            <Link to="/inventory-alerts" className="text-xs text-orange-600 hover:text-orange-700 font-medium">View All</Link>
          </div>
          <div>
            {alerts?.lowStock.slice(0, 5).map((a) => (
              <div key={a.medicineId} className="flex items-center justify-between py-1.5 border-b border-amber-100 last:border-0">
                <span className="text-xs font-medium text-ink-900 truncate">{a.name}</span>
                <span className={`text-xs font-medium flex-shrink-0 ${a.currentStock <= 5 ? "text-red-700" : "text-amber-700"}`}>
                  {a.currentStock} in stock
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row: Recent Sales + Live Activity */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Recent Sales — table/list */}
        <div className="bg-sand-25 rounded-lg p-4 shadow-card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-ink-800">Recent Sales</h2>
            <button className="text-xs text-ink-muted hover:text-ink-800 flex items-center gap-1">
              Today <ChevronDown size={12} />
            </button>
          </div>
          <div>
            {barData.slice(0, 4).map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-sand-100 last:border-0">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span className="text-[10px] text-ink-muted w-4 text-right flex-shrink-0">{i + 1}</span>
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-ink-900 truncate">{item.name}</div>
                    <div className="text-[10px] text-ink-muted">{ghs(item.revenue)}</div>
                  </div>
                </div>
                <span className="text-[10px] text-pine-600 bg-pine-50 px-2 py-0.5 rounded-full font-medium flex-shrink-0">Paid</span>
              </div>
            ))}
          </div>
        </div>

        {/* Live Activity — recessed panel treatment */}
        <div className="bg-sand-75 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-ink-800">Live Activity</h2>
            <span className="text-xs text-pine-600 flex items-center gap-1">
              <CircleDot size={10} className="fill-pine-400 text-pine-400" /> live
            </span>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
            {feed.length === 0 && (
              <div className="text-center py-6">
                <Activity size={20} className="mx-auto text-ink-800/15 mb-1.5" />
                <p className="text-xs text-ink-muted">Waiting for activity…</p>
              </div>
            )}
            {feed.map((e) => (
              <div key={e.id} className="bg-sand-25 rounded-lg px-3 py-2 text-xs text-ink-800/70 border-l-2 border-orange-300">
                <div className="line-clamp-1">{e.text}</div>
                <div className="text-[10px] text-ink-muted mt-0.5">{e.time}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Staff Performance */}
      <StaffPerformancePanel />

      {loginToast && (
        <Toast message={loginToast.message} type={loginToast.type} onClose={() => setLoginToast(null)} duration={5000} />
      )}
    </div>
  );
}

/* ─── Main Dashboard ─── */
export default function Dashboard() {
  const { user } = useAuth();

  if (MANAGER_ROLES.includes(user?.role ?? "")) {
    return <ManagerDashboardView />;
  }

  return <StaffDashboardView userName={user?.name ?? ""} role={user?.role ?? ""} />;
}
