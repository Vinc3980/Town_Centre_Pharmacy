import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  AlertTriangle, Clock, Search, ChevronDown, ChevronRight,
  Package, Skull,
} from "lucide-react";
import { fetchInventoryAlerts } from "../api/dashboard";
import { InventoryAlerts as InventoryAlertsType } from "../types";
import Badge from "../components/ui/Badge";
import EmptyState from "../components/ui/EmptyState";
import { TableSkeleton } from "../components/ui/Skeleton";

function ghs(n: number) {
  return "GHS " + n.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function SectionHeader({
  title,
  icon: Icon,
  count,
  color,
  expanded,
  onToggle,
}: {
  title: string;
  icon: typeof AlertTriangle;
  count: number;
  color: string;
  expanded: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="w-full flex items-center justify-between p-4 bg-white rounded-xl border border-sand-200 hover:border-sand-300 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
    >
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
          <Icon size={20} />
        </div>
        <div className="text-left">
          <h2 className="text-sm font-medium text-ink-900">{title}</h2>
          <p className="text-xs text-ink-900/45">{count} item{count !== 1 ? "s" : ""} found</p>
        </div>
      </div>
      {expanded ? <ChevronDown size={18} className="text-ink-900/30" /> : <ChevronRight size={18} className="text-ink-900/30" />}
    </button>
  );
}

function LowStockTable({ items }: { items: InventoryAlertsType["lowStock"] }) {
  if (items.length === 0) {
    return <EmptyState title="No low stock items" description="All products are above reorder level" />;
  }

  return (
    <div className="bg-white rounded-xl border border-sand-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-sand-200 bg-sand-50/50">
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Product</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Current Stock</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Reorder Level</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Min Stock</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-sand-100">
            {items.map((item) => {
              const ratio = item.reorderLevel > 0 ? item.currentStock / item.reorderLevel : 0;
              const status = item.currentStock === 0 ? "Out of Stock" : ratio <= 0.5 ? "Critical" : "Low";
              const badgeVariant = item.currentStock === 0 ? "red" : ratio <= 0.5 ? "red" : "amber";
              return (
                <tr key={item.medicineId} className="hover:bg-sand-50/50 transition">
                  <td className="px-4 py-3 font-medium text-ink-900">{item.name}</td>
                  <td className="px-4 py-3 tabular-nums text-ink-900/70">{item.currentStock}</td>
                  <td className="px-4 py-3 tabular-nums text-ink-900/70">{item.reorderLevel}</td>
                  <td className="px-4 py-3 tabular-nums text-ink-900/70">{item.minStock}</td>
                  <td className="px-4 py-3">
                    <Badge variant={badgeVariant}>{status}</Badge>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ExpiringSoonTable({ items }: { items: InventoryAlertsType["expiringSoon"] }) {
  if (items.length === 0) {
    return <EmptyState title="No expiring items" description="No batches expiring within 30 days" />;
  }

  return (
    <div className="bg-white rounded-xl border border-sand-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-sand-200 bg-sand-50/50">
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Product</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Batch Number</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Quantity</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Expiry Date</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Days Left</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-sand-100">
            {items.map((item) => {
              const daysLeft = Math.ceil(item.daysUntilExpiry);
              const badgeVariant = daysLeft <= 7 ? "red" : daysLeft <= 14 ? "amber" : "pine";
              return (
                <tr key={item.batchNumber} className="hover:bg-sand-50/50 transition">
                  <td className="px-4 py-3 font-medium text-ink-900">{item.medicine}</td>
                  <td className="px-4 py-3 font-mono text-xs text-ink-900/60">{item.batchNumber}</td>
                  <td className="px-4 py-3 tabular-nums text-ink-900/70">{item.quantity}</td>
                  <td className="px-4 py-3 text-ink-900/70">{new Date(item.expiryDate).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <Badge variant={badgeVariant}>{daysLeft}d</Badge>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ExpiredTable({ items }: { items: InventoryAlertsType["expired"] }) {
  if (items.length === 0) {
    return <EmptyState title="No expired items" description="No expired batches in inventory" />;
  }

  return (
    <div className="bg-white rounded-xl border border-sand-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-sand-200 bg-sand-50/50">
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Product</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Batch Number</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Quantity</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Expiry Date</th>
              <th className="text-left px-4 py-3 font-medium text-ink-900/60">Days Expired</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-sand-100">
            {items.map((item) => (
              <tr key={item.batchNumber} className="hover:bg-sand-50/50 transition">
                <td className="px-4 py-3 font-medium text-ink-900">{item.medicine}</td>
                <td className="px-4 py-3 font-mono text-xs text-ink-900/60">{item.batchNumber}</td>
                <td className="px-4 py-3 tabular-nums text-ink-900/70">{item.quantity}</td>
                <td className="px-4 py-3 text-ink-900/70">{new Date(item.expiryDate).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <Badge variant="red">{Math.ceil(item.daysExpired)}d</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function InventoryAlerts() {
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ lowStock: true, expiringSoon: true, expired: true });

  const { data: alerts, isLoading } = useQuery({
    queryKey: ["inventory-alerts"],
    queryFn: fetchInventoryAlerts,
  });

  const filtered = useMemo(() => {
    if (!alerts) return { lowStock: [], expiringSoon: [], expired: [] };
    if (!search.trim()) return alerts;
    const q = search.toLowerCase();
    return {
      lowStock: alerts.lowStock.filter((a) => a.name.toLowerCase().includes(q)),
      expiringSoon: alerts.expiringSoon.filter((a) => a.medicine.toLowerCase().includes(q) || a.batchNumber.toLowerCase().includes(q)),
      expired: alerts.expired.filter((a) => a.medicine.toLowerCase().includes(q) || a.batchNumber.toLowerCase().includes(q)),
    };
  }, [alerts, search]);

  function toggleSection(key: string) {
    setExpanded((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  if (isLoading) return <TableSkeleton />;

  const totalCount = (alerts?.lowStock.length ?? 0) + (alerts?.expiringSoon.length ?? 0) + (alerts?.expired.length ?? 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-ink-900">Inventory Alerts</h1>
        <p className="text-sm text-ink-900/45">{totalCount} alert{totalCount !== 1 ? "s" : ""} across all categories</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white rounded-xl border border-sand-200 p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-clay-50 flex items-center justify-center">
            <AlertTriangle size={18} className="text-clay-600" />
          </div>
          <div>
            <div className="text-xl font-display text-ink-900">{alerts?.lowStock.length ?? 0}</div>
            <div className="text-xs text-ink-900/45">Low Stock</div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-sand-200 p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
            <Clock size={18} className="text-amber-600" />
          </div>
          <div>
            <div className="text-xl font-display text-ink-900">{alerts?.expiringSoon.length ?? 0}</div>
            <div className="text-xs text-ink-900/45">Expiring Soon</div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-sand-200 p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
            <Skull size={18} className="text-red-600" />
          </div>
          <div>
            <div className="text-xl font-display text-ink-900">{alerts?.expired.length ?? 0}</div>
            <div className="text-xs text-ink-900/45">Expired</div>
          </div>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
        <input
          type="text"
          placeholder="Search by product or batch name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
        />
      </div>

      <div className="space-y-3">
        <div className="space-y-2">
          <SectionHeader
            title="Low Stock Alerts"
            icon={AlertTriangle}
            count={filtered.lowStock.length}
            color="bg-clay-50 text-clay-600"
            expanded={expanded.lowStock}
            onToggle={() => toggleSection("lowStock")}
          />
          {expanded.lowStock && <LowStockTable items={filtered.lowStock} />}
        </div>

        <div className="space-y-2">
          <SectionHeader
            title="Expiring Soon"
            icon={Clock}
            count={filtered.expiringSoon.length}
            color="bg-amber-50 text-amber-600"
            expanded={expanded.expiringSoon}
            onToggle={() => toggleSection("expiringSoon")}
          />
          {expanded.expiringSoon && <ExpiringSoonTable items={filtered.expiringSoon} />}
        </div>

        <div className="space-y-2">
          <SectionHeader
            title="Expired"
            icon={Package}
            count={filtered.expired.length}
            color="bg-red-50 text-red-600"
            expanded={expanded.expired}
            onToggle={() => toggleSection("expired")}
          />
          {expanded.expired && <ExpiredTable items={filtered.expired} />}
        </div>
      </div>
    </div>
  );
}
