import React, { useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Search, Plus, Minus, Trash2, ShoppingCart, Banknote, Smartphone, CreditCard,
  Pause, X, UserPlus, Tag, Receipt, Barcode, Loader2, Pill, Clock, AlertTriangle, Keyboard, Eye,
  HandCoins,
} from "lucide-react";
import { fetchMedicines } from "../api/medicines";
import {
  createSale, holdSale, resumeSale, fetchHeldSales, deleteHeldSale, getSaleReceipt, lookupBarcode,
} from "../api/sales";
import { CartLine, HeldSale, Medicine, SalePayment, SaleReceipt } from "../types";
import { useAuth } from "../context/AuthContext";
import { getSocket } from "../lib/socket";
import Toast from "../components/ui/Toast";
import Modal from "../components/ui/Modal";
import Button from "../components/ui/Button";
import NumericKeypad from "../components/NumericKeypad";

function ghs(n: number) {
  return "GHS " + n.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

const PAY_METHODS: { key: SalePayment["method"]; label: string; icon: typeof Banknote }[] = [
  { key: "cash", label: "Cash", icon: Banknote },
  { key: "mobile_money", label: "Mobile Money", icon: Smartphone },
  { key: "card", label: "Card", icon: CreditCard },
  { key: "bank_transfer", label: "Bank Transfer", icon: CreditCard },
  { key: "credit", label: "Credit", icon: HandCoins },
  { key: "other", label: "Other", icon: CreditCard },
];

export default function POS() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const canDiscount = user?.permissions?.includes("apply_discounts") ?? false;

  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounce(search, 250);
  const [barcodeInput, setBarcodeInput] = useState("");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  const [checkingOut, setCheckingOut] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [tax, setTax] = useState(0);
  const [selectedCustomer, setSelectedCustomer] = useState<string | undefined>();
  const [customerSearch, setCustomerSearch] = useState("");
  const [showCustomerSearch, setShowCustomerSearch] = useState(false);
  const [showReceipt, setShowReceipt] = useState<SaleReceipt | null>(null);
  const [heldSales, setHeldSales] = useState<HeldSale[]>([]);
  const [showHeld, setShowHeld] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<SalePayment["method"]>("cash");
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [viewingImage, setViewingImage] = useState<{ url: string; name: string; medicine: Medicine } | null>(null);
  const [showGrid, setShowGrid] = useState(false);
  const [expandedProduct, setExpandedProduct] = useState<Medicine | null>(null);

  const barcodeRef = useRef<HTMLInputElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    barcodeRef.current?.focus();
  }, []);

  const showToast = useCallback((message: string, type: "success" | "error" | "info" = "info") => {
    setToast({ message, type });
  }, []);

  const { data: medicines, isLoading: medicinesLoading } = useQuery({
    queryKey: ["medicines", debouncedSearch],
    queryFn: () => fetchMedicines(debouncedSearch),
    placeholderData: (prev) => prev,
  });

  const { data: customers } = useQuery({
    queryKey: ["customers", customerSearch],
    queryFn: async () => {
      const { data } = await (await import("../lib/apiClient")).api.get(
        `/customers${customerSearch ? `?search=${encodeURIComponent(customerSearch)}` : ""}`
      );
      return data as { _id: string; name: string; phone: string }[];
    },
    enabled: showCustomerSearch,
  });

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => {
      const { data } = await (await import("../lib/apiClient")).api.get("/categories");
      return data as { _id: string; name: string }[];
    },
  });

  const { data: currentSession, refetch: refetchSession } = useQuery({
    queryKey: ["daily-session-current"],
    queryFn: async () => {
      const { data } = await (await import("../lib/apiClient")).api.get("/daily/sessions/current");
      return data as { _id: string; status: string } | null;
    },
  });

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    function onSessionUpdate() { refetchSession(); }
    socket.on("daily.session.opened", onSessionUpdate);
    socket.on("daily.session.closed", onSessionUpdate);
    return () => {
      socket.off("daily.session.opened", onSessionUpdate);
      socket.off("daily.session.closed", onSessionUpdate);
    };
  }, [refetchSession]);

  const hasOpenSession = currentSession?.status === "open";

  const loadHeld = useCallback(async () => {
    try {
      const sales = await fetchHeldSales();
      setHeldSales(sales);
      setShowHeld(true);
    } catch {
      showToast("Failed to load held sales", "error");
    }
  }, [showToast]);

  async function handleBarcodeScan(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key !== "Enter") return;
    const code = barcodeInput.trim();
    if (!code) return;
    try {
      const med = await lookupBarcode(code);
      if (med.totalStock <= 0) {
        showToast(`${med.name} is out of stock`, "error");
        return;
      }
      addToCart(med);
      setBarcodeInput("");
    } catch {
      showToast("No product found with that barcode", "error");
    }
  }

  function addToCart(m: { _id: string; name: string; sellingPrice: number; totalStock: number }) {
    if (m.totalStock <= 0) return;
    setCart((c) => {
      const existing = c.find((it) => it.medicineId === m._id);
      if (existing) {
        return c.map((it) =>
          it.medicineId === m._id
            ? { ...it, qty: Math.min(it.qty + 1, m.totalStock) }
            : it
        );
      }
      return [...c, { medicineId: m._id, name: m.name, price: m.sellingPrice, qty: 1, stock: m.totalStock, discount: 0 }];
    });
    setBarcodeInput("");
    barcodeRef.current?.focus();
  }

  function changeQty(id: string, delta: number) {
    setCart((c) =>
      c.map((it) =>
        it.medicineId === id
          ? { ...it, qty: Math.max(1, Math.min(it.qty + delta, it.stock)) }
          : it
      )
    );
  }

  function setItemDiscount(id: string, disc: number) {
    setCart((c) =>
      c.map((it) =>
        it.medicineId === id
          ? { ...it, discount: Math.max(0, Math.min(disc, it.price * it.qty)) }
          : it
      )
    );
  }

  function removeItem(id: string) {
    setCart((c) => c.filter((it) => it.medicineId !== id));
  }

  function clearCart() {
    setCart([]);
    setDiscount(0);
    setTax(0);
    setSelectedCustomer(undefined);
  }

  const subtotal = cart.reduce((s, it) => s + it.price * it.qty, 0);
  const cartDiscount = cart.reduce((s, it) => s + it.discount, 0);
  const total = Math.max(0, subtotal - cartDiscount - discount + tax);

  async function handleCheckout(payments: SalePayment[], amountReceived?: number) {
    if (cart.length === 0 || checkingOut) return;
    if (!hasOpenSession) {
      showToast("Please open a daily session before processing sales", "error");
      return;
    }
    setCheckingOut(true);
    try {
      const sale = await createSale(
        cart.map((it) => ({ medicine: it.medicineId, quantity: it.qty, discount: it.discount })),
        payments,
        { customer: selectedCustomer, tax, discount, amountReceived }
      );
      showToast("Payment confirmed", "success");
      const receipt = await getSaleReceipt(sale._id);
      setShowReceipt(receipt);
      clearCart();
      queryClient.invalidateQueries({ queryKey: ["medicines"] });
    } catch (err) {
      console.error("Checkout error:", err);
      const message = (err as { response?: { data?: { message?: string } } }).response?.data?.message ?? "Couldn't complete the sale. Try again.";
      showToast(message, "error");
    } finally {
      setCheckingOut(false);
    }
  }

  async function handleHold() {
    if (cart.length === 0) return;
    try {
      await holdSale(
        cart.map((it) => ({ medicine: it.medicineId, quantity: it.qty, discount: it.discount })),
        { customer: selectedCustomer, discount, tax }
      );
      clearCart();
      showToast("Sale held", "success");
    } catch (err) {
      const message = (err as { response?: { data?: { message?: string } } }).response?.data?.message ?? "Failed to hold sale";
      showToast(message, "error");
    }
  }

  async function handleResumeHeld(held: HeldSale) {
    try {
      await deleteHeldSale(held._id);
      setShowHeld(false);
      showToast("Sale resumed — use payment modal to complete", "info");
    } catch {
      showToast("Failed to resume held sale", "error");
    }
  }

  async function handleResumeWithPayment(held: HeldSale, payments: SalePayment[], amountReceived?: number) {
    setCheckingOut(true);
    try {
      const sale = await resumeSale(held._id, payments, { amountReceived });
      showToast("Payment confirmed", "success");
      const receipt = await getSaleReceipt(sale._id);
      setShowReceipt(receipt);
      clearCart();
      setShowHeld(false);
      queryClient.invalidateQueries({ queryKey: ["medicines"] });
    } catch (err) {
      const message = (err as { response?: { data?: { message?: string } } }).response?.data?.message ?? "Failed to resume sale";
      showToast(message, "error");
    } finally {
      setCheckingOut(false);
    }
  }

  return (
    <div className="grid lg:grid-cols-3 gap-4 lg:gap-6 h-[calc(100vh-8rem)]">
      <div className="lg:col-span-2 space-y-3 flex flex-col min-h-0">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Barcode size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
            <input
              ref={barcodeRef}
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              onKeyDown={handleBarcodeScan}
              placeholder="Scan barcode → Enter"
              aria-label="Barcode scanner input"
              className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 font-mono transition"
            />
          </div>
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-900/30" />
            <input
              ref={searchRef}
              value={search}
              onChange={(e) => { setSearch(e.target.value); if (e.target.value) setShowGrid(true); }}
              placeholder="Search product…"
              aria-label="Search products"
              className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
            />
          </div>
        </div>

        {categories && categories.length > 0 && (
          <div className="flex gap-2 items-center">
            <button
              onClick={() => {
                if (showGrid && !search && !categoryFilter) {
                  setShowGrid(false);
                } else {
                  setShowGrid(true);
                  setCategoryFilter("");
                  setSearch("");
                }
              }}
              className={`px-3 py-1.5 text-xs rounded-lg border transition font-medium ${
                showGrid && !categoryFilter && !search
                  ? "bg-pine-600 text-white border-pine-600"
                  : "bg-white text-ink-700 border-sand-200 hover:border-pine-400"
              }`}
            >
              View All
            </button>
            <select
              value={categoryFilter}
              onChange={(e) => { setCategoryFilter(e.target.value); setShowGrid(true); }}
              className="px-3 py-1.5 text-xs border border-sand-200 rounded-lg bg-white text-ink-900 outline-none focus:border-pine-500 transition"
              aria-label="Filter by category"
            >
              <option value="">All Categories</option>
              {categories.map((c) => (
                <option key={c._id} value={c._id}>{c.name}</option>
              ))}
            </select>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          {!showGrid && (
            <div className="flex flex-col items-center justify-center h-full text-ink-900/30">
              <ShoppingCart size={48} strokeWidth={1} />
              <p className="mt-3 text-sm">Search for a product or click "View All" to browse</p>
            </div>
          )}

          {showGrid && (
            <>
              {/* Table view for search results */}
              {search && !categoryFilter ? (
                <div className="border border-sand-200 rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-sand-50 text-left">
                        <th className="px-3 py-2 text-[11px] font-medium text-ink-500">Product Name</th>
                        <th className="px-3 py-2 text-[11px] font-medium text-ink-500">Expiry Date</th>
                        <th className="px-3 py-2 text-[11px] font-medium text-ink-500">Unit Price</th>
                        <th className="px-3 py-2 text-[11px] font-medium text-ink-500 text-right">Stock</th>
                        <th className="px-3 py-2 text-[11px] font-medium text-ink-500 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-sand-100">
                      {medicinesLoading && (
                        <tr><td colSpan={5} className="px-3 py-8 text-center text-ink-900/30 text-sm"><Loader2 size={16} className="animate-spin inline mr-2" />Searching...</td></tr>
                      )}
                      {!medicinesLoading && medicines?.filter((m) => !categoryFilter || (typeof m.category === "object" && m.category?._id === categoryFilter)).map((m) => {
                        const out = m.totalStock <= 0;
                        const inCart = cart.find((it) => it.medicineId === m._id);
                        const expiryDays = m.nearestExpiry ? Math.ceil((new Date(m.nearestExpiry).getTime() - Date.now()) / 86400000) : null;
                        return (
                          <tr key={m._id} className={`${out ? "opacity-40" : ""} hover:bg-sand-50 transition`}>
                            <td className="px-3 py-2.5">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded bg-sand-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                                  {m.imageUrl ? <img src={m.imageUrl} alt={m.name} className="w-full h-full object-cover" /> : <Pill size={14} className="text-pine-400" />}
                                </div>
                                <div className="min-w-0">
                                  <p className="font-medium text-ink-900 truncate">{m.name}</p>
                                  {m.genericName && <p className="text-[11px] text-ink-400 truncate">{m.genericName}</p>}
                                </div>
                              </div>
                            </td>
                            <td className="px-3 py-2.5">
                              {m.nearestExpiry ? (
                                <span className={`text-xs ${expiryDays !== null && expiryDays <= 30 ? "text-clay-600 font-medium" : "text-ink-500"}`}>
                                  {new Date(m.nearestExpiry).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                                  {expiryDays !== null && <span className="ml-1 text-[10px]">({expiryDays}d)</span>}
                                </span>
                              ) : <span className="text-xs text-ink-300">—</span>}
                            </td>
                            <td className="px-3 py-2.5 font-semibold text-sm tabular-nums">{ghs(m.sellingPrice)}</td>
                            <td className="px-3 py-2.5 text-right">
                              <span className={`text-xs font-medium ${m.totalStock <= 10 ? "text-clay-600" : "text-ink-500"}`}>
                                {m.totalStock}
                              </span>
                            </td>
                            <td className="px-3 py-2.5 text-right">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => setExpandedProduct(m)}
                                  className="p-1.5 hover:bg-sand-100 rounded-lg transition"
                                  title="View details"
                                >
                                  <Eye size={14} className="text-ink-400" />
                                </button>
                                {!out && (
                                  <button
                                    onClick={() => addToCart(m)}
                                    className="p-1.5 hover:bg-pine-50 rounded-lg transition"
                                    title={inCart ? `In cart (${inCart.qty})` : "Add to cart"}
                                  >
                                    <Plus size={14} className={inCart ? "text-pine-600" : "text-ink-400"} />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                      {!medicinesLoading && medicines && medicines.length === 0 && (
                        <tr><td colSpan={5} className="px-3 py-8 text-center text-ink-900/30 text-sm">No products found for "{search}"</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              ) : (
                /* Grid view for categories / View All */
                <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-2 auto-rows-min content-start">
                  {medicinesLoading && (
                    <div className="sm:col-span-2 xl:col-span-3 flex items-center justify-center py-8 text-ink-900/30 text-sm">
                      <Loader2 size={18} className="animate-spin mr-2" /> Loading products…
                    </div>
                  )}
                  {!medicinesLoading && medicines?.filter((m) => !categoryFilter || (typeof m.category === "object" && m.category?._id === categoryFilter)).map((m) => {
                    const out = m.totalStock <= 0;
                    const inCart = cart.find((it) => it.medicineId === m._id);
                    const expiryDays = m.nearestExpiry ? Math.ceil((new Date(m.nearestExpiry).getTime() - Date.now()) / 86400000) : null;
                    const expiringSoon = expiryDays !== null && expiryDays <= 30;
                    return (
                      <button
                        key={m._id}
                        onClick={() => addToCart(m)}
                        disabled={out}
                        className={`text-left bg-white rounded-xl border p-3 hover:border-pine-400 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30 ${
                          out ? "opacity-40 cursor-not-allowed border-sand-200" : inCart ? "border-pine-400 bg-pine-50/50" : "border-sand-200"
                        }`}
                        aria-label={`${m.name}, ${ghs(m.sellingPrice)}, ${m.totalStock} in stock${out ? ", out of stock" : ""}`}
                      >
                        <div className="flex gap-3">
                          <div className="w-12 h-12 rounded-lg bg-sand-100 flex items-center justify-center flex-shrink-0 overflow-hidden relative group">
                            {m.imageUrl ? (
                              <>
                                <img src={m.imageUrl} alt={m.name} className="w-full h-full object-cover" />
                                <button
                                  type="button"
                                  onClick={(e) => { e.stopPropagation(); setViewingImage({ url: m.imageUrl!, name: m.name, medicine: m }); }}
                                  className="absolute inset-0 bg-ink-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition focus:outline-none"
                                  aria-label={`View image of ${m.name}`}
                                >
                                  <Eye size={16} className="text-white" />
                                </button>
                              </>
                            ) : (
                              <Pill size={20} className="text-pine-400" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-sm mb-0.5 text-ink-900 truncate">{m.name}</div>
                            {m.genericName && <div className="text-[11px] text-ink-900/40 truncate">{m.genericName}</div>}
                            <div className="flex items-center gap-2 mt-1">
                              {m.form && <span className="text-[10px] bg-sand-100 text-ink-900/50 px-1.5 py-0.5 rounded">{m.form}</span>}
                              {m.prescriptionRequired && (
                                <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full font-medium">Rx</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-sand-100">
                          <span className="font-semibold text-pine-700 text-sm">{ghs(m.sellingPrice)}</span>
                          <div className="flex items-center gap-2">
                            {expiryDays !== null && (
                              <span className={`text-[10px] flex items-center gap-0.5 ${expiringSoon ? "text-clay-600" : "text-ink-900/35"}`}>
                                {expiringSoon ? <AlertTriangle size={10} /> : <Clock size={10} />}
                                {expiryDays}d
                              </span>
                            )}
                            <span className={`text-xs font-medium ${m.totalStock <= 10 ? "text-clay-600" : "text-ink-900/40"}`}>
                              {m.totalStock} in stock
                            </span>
                          </div>
                        </div>
                        {inCart && (
                          <div className="mt-1 text-[10px] text-pine-600 font-medium">
                            ×{inCart.qty} in cart
                          </div>
                        )}
                      </button>
                    );
                  })}
                  {!medicinesLoading && medicines && medicines.length === 0 && (
                    <div className="sm:col-span-2 xl:col-span-3 text-center py-8 text-ink-900/30 text-sm">
                      No products found
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-sand-200 p-4 h-fit lg:h-full lg:overflow-y-auto flex flex-col">
        <div className="mb-3">
          <button
            onClick={() => setShowCustomerSearch(!showCustomerSearch)}
            className="flex items-center gap-2 text-xs text-ink-900/50 hover:text-pine-700 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30 rounded px-1 py-0.5"
          >
            <UserPlus size={14} />
            {selectedCustomer ? "Customer selected" : "Select customer (optional)"}
          </button>
          {showCustomerSearch && (
            <div className="mt-2 space-y-2">
              <input
                value={customerSearch}
                onChange={(e) => setCustomerSearch(e.target.value)}
                placeholder="Search by name or phone"
                aria-label="Search customers"
                className="w-full px-3 py-2 rounded-lg border border-sand-200 text-xs outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
              />
              {customers && customers.length > 0 && (
                <div className="max-h-32 overflow-y-auto space-y-1" role="listbox">
                  {customers.map((c) => (
                    <button
                      key={c._id}
                      role="option"
                      aria-selected={selectedCustomer === c._id}
                      onClick={() => {
                        setSelectedCustomer(c._id);
                        setShowCustomerSearch(false);
                        setCustomerSearch("");
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs hover:bg-pine-50 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30 ${
                        selectedCustomer === c._id ? "bg-pine-50 text-pine-700" : ""
                      }`}
                    >
                      {c.name} — {c.phone}
                    </button>
                  ))}
                </div>
              )}
              {selectedCustomer && (
                <button
                  onClick={() => setSelectedCustomer(undefined)}
                  className="text-xs text-clay-600 hover:text-clay-800 focus:outline-none focus:ring-2 focus:ring-clay-500/30 rounded px-1"
                >
                  Clear customer
                </button>
              )}
            </div>
          )}
        </div>

        <h2 className="text-sm font-medium mb-2 flex items-center justify-between text-ink-900/70">
          <span className="flex items-center gap-2"><ShoppingCart size={16} /> Cart</span>
          <div className="flex gap-1">
            <button
              onClick={loadHeld}
              className="p-1.5 rounded-md hover:bg-sand-100 text-ink-900/30 hover:text-ink-900/60 focus:outline-none focus:ring-2 focus:ring-pine-500/30"
              title="View held sales"
              aria-label="View held sales"
            >
              <Pause size={14} />
            </button>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="p-1.5 rounded-md hover:bg-clay-50 text-ink-900/30 hover:text-clay-600 focus:outline-none focus:ring-2 focus:ring-clay-500/30"
                title="Clear cart"
                aria-label="Clear cart"
              >
                <X size={14} />
              </button>
            )}
          </div>
        </h2>

        {cart.length === 0 ? (
          <p className="text-sm text-ink-900/35 py-8 text-center">
            Cart is empty<br />
            <span className="text-xs">Scan a barcode or tap a product</span>
          </p>
        ) : (
          <div className="space-y-2 mb-3 max-h-60 overflow-y-auto pr-1">
            {cart.map((it) => (
              <div key={it.medicineId} className="flex items-center justify-between gap-2 bg-sand-50 rounded-lg px-3 py-2">
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate text-ink-900 font-medium">{it.name}</div>
                  <div className="text-xs text-ink-900/40">
                    {ghs(it.price)} each
                    {it.discount > 0 && (
                      <span className="text-clay-600 ml-1">-{ghs(it.discount)}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => changeQty(it.medicineId, -1)}
                    className="w-7 h-7 rounded-full border border-sand-200 flex items-center justify-center hover:bg-sand-100 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
                    aria-label={`Decrease ${it.name} quantity`}
                  >
                    <Minus size={12} />
                  </button>
                  <span className="w-6 text-center text-sm font-medium tabular-nums">{it.qty}</span>
                  <button
                    onClick={() => changeQty(it.medicineId, 1)}
                    className="w-7 h-7 rounded-full border border-sand-200 flex items-center justify-center hover:bg-sand-100 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
                    aria-label={`Increase ${it.name} quantity`}
                  >
                    <Plus size={12} />
                  </button>
                  {canDiscount && (
                    <input
                      type="number"
                      value={it.discount || ""}
                      onChange={(e) => setItemDiscount(it.medicineId, Math.max(0, Number(e.target.value)))}
                      placeholder="0"
                      aria-label={`${it.name} discount`}
                      className="w-14 text-right px-1 py-0.5 rounded border border-sand-200 text-xs outline-none focus:border-pine-500 focus:ring-1 focus:ring-pine-500/20 tabular-nums"
                    />
                  )}
                  <button
                    onClick={() => removeItem(it.medicineId)}
                    className="ml-1 text-ink-900/30 hover:text-clay-600 focus:outline-none focus:ring-2 focus:ring-clay-500/30 rounded p-0.5"
                    aria-label={`Remove ${it.name} from cart`}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {cart.length > 0 && (
          <div className="space-y-2 border-t border-sand-200 pt-3">
            <div className="flex items-center justify-between text-sm text-ink-900/50">
              <span>Subtotal</span>
              <span className="tabular-nums">{ghs(subtotal)}</span>
            </div>

            {cartDiscount > 0 && (
              <div className="flex items-center justify-between text-sm text-clay-600">
                <span>Item discounts</span>
                <span className="tabular-nums">-{ghs(cartDiscount)}</span>
              </div>
            )}

            {canDiscount && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-900/50 flex items-center gap-1"><Tag size={12} /> Discount</span>
                <input
                  type="number"
                  value={discount || ""}
                  onChange={(e) => setDiscount(Math.max(0, Number(e.target.value)))}
                  placeholder="0.00"
                  aria-label="Total discount"
                  className="w-20 text-right px-2 py-1 rounded border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-1 focus:ring-pine-500/20 tabular-nums"
                />
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <span className="text-ink-900/50">Tax</span>
              <input
                type="number"
                value={tax || ""}
                onChange={(e) => setTax(Math.max(0, Number(e.target.value)))}
                placeholder="0.00"
                aria-label="Tax amount"
                className="w-20 text-right px-2 py-1 rounded border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-1 focus:ring-pine-500/20 tabular-nums"
              />
            </div>

            <div className="border-t border-sand-200 pt-2 flex items-center justify-between">
              <span className="text-sm font-medium text-ink-900/70">Total</span>
              <span className="text-xl font-display tabular-nums">{ghs(total)}</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 mt-3">
          {PAY_METHODS.filter((m) => ["cash", "mobile_money", "card", "credit"].includes(m.key)).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => { setPaymentMethod(key); setShowPayment(true); }}
              disabled={cart.length === 0 || checkingOut || !hasOpenSession}
              className="flex flex-col items-center gap-1 py-3 rounded-lg text-xs font-medium text-white bg-pine-700 hover:bg-pine-800 disabled:opacity-40 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
              aria-label={`Pay with ${label}`}
            >
              <Icon size={16} />
              {label}
            </button>
          ))}
        </div>

        {!hasOpenSession && (
          <div className="mt-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-xs text-center">
            Open a daily session before processing sales
          </div>
        )}

        {cart.length > 0 && (
          <button
            onClick={() => { setPaymentMethod("cash"); setShowPayment(true); }}
            disabled={checkingOut || !hasOpenSession}
            className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-medium border border-sand-200 text-ink-900/60 hover:bg-sand-50 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
          >
            More payment methods
          </button>
        )}

        {cart.length > 0 && (
          <button
            onClick={handleHold}
            className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-medium border border-sand-200 text-ink-900/60 hover:bg-sand-50 transition focus:outline-none focus:ring-2 focus:ring-pine-500/30"
          >
            <Pause size={14} />
            Hold sale
          </button>
        )}
      </div>

      {showPayment && (
        <PaymentModal
          total={total}
          initialMethod={paymentMethod}
          onConfirm={(payments, amountReceived) => {
            setShowPayment(false);
            handleCheckout(payments, amountReceived);
          }}
          onCancel={() => setShowPayment(false)}
        />
      )}

      {showHeld && (
        <HeldSalesModal
          heldSales={heldSales}
          onResume={(h) => handleResumeHeld(h)}
          onResumeWithPayment={(h, payments, amt) => {
            setShowHeld(false);
            handleResumeWithPayment(h, payments, amt);
          }}
          onDelete={async (h) => {
            await deleteHeldSale(h._id);
            setHeldSales((prev) => prev.filter((s) => s._id !== h._id));
          }}
          onClose={() => setShowHeld(false)}
        />
      )}

      {showReceipt && (
        <ReceiptModal receipt={showReceipt} onClose={() => setShowReceipt(null)} />
      )}

      {viewingImage && (
        <Modal open onClose={() => setViewingImage(null)} title={viewingImage.name} size="lg">
          <div className="flex flex-col md:flex-row gap-5">
            <div className="flex-shrink-0 flex items-center justify-center">
              <img src={viewingImage.url} alt={viewingImage.name} className="w-full md:w-64 h-48 md:h-64 rounded-lg object-cover border border-sand-200" />
            </div>
            <div className="flex-1 space-y-3 text-sm">
              <div>
                <div className="text-ink-900 font-medium text-base">{viewingImage.name}</div>
                {viewingImage.medicine.genericName && <div className="text-ink-900/50 text-xs mt-0.5">{viewingImage.medicine.genericName}</div>}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-sand-50 rounded-lg px-3 py-2">
                  <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Price</div>
                  <div className="text-pine-700 font-semibold">{ghs(viewingImage.medicine.sellingPrice)}</div>
                </div>
                <div className="bg-sand-50 rounded-lg px-3 py-2">
                  <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Stock</div>
                  <div className={`font-semibold ${viewingImage.medicine.totalStock <= 10 ? "text-clay-600" : "text-ink-900"}`}>
                    {viewingImage.medicine.totalStock} {viewingImage.medicine.totalStock <= 0 ? "(Out of stock)" : "in stock"}
                  </div>
                </div>
              </div>
              <div className="space-y-1.5 text-xs">
                {viewingImage.medicine.barcode && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Barcode</span><span className="font-mono text-ink-900">{viewingImage.medicine.barcode}</span></div>
                )}
                <div className="flex justify-between"><span className="text-ink-900/50">SKU</span><span className="font-mono text-ink-900">{viewingImage.medicine.sku}</span></div>
                {viewingImage.medicine.form && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Form</span><span className="text-ink-900 capitalize">{viewingImage.medicine.form}</span></div>
                )}
                {viewingImage.medicine.strength && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Strength</span><span className="text-ink-900">{viewingImage.medicine.strength}</span></div>
                )}
                {viewingImage.medicine.dosage && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Dosage</span><span className="text-ink-900">{viewingImage.medicine.dosage}</span></div>
                )}
                {viewingImage.medicine.brand && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Brand</span><span className="text-ink-900">{viewingImage.medicine.brand}</span></div>
                )}
                {viewingImage.medicine.manufacturer && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Manufacturer</span><span className="text-ink-900">{viewingImage.medicine.manufacturer}</span></div>
                )}
                {viewingImage.medicine.nearestExpiry && (
                  <div className="flex justify-between">
                    <span className="text-ink-900/50">Expiry</span>
                    <span className={Math.ceil((new Date(viewingImage.medicine.nearestExpiry).getTime() - Date.now()) / 86400000) <= 30 ? "text-clay-600 font-medium" : "text-ink-900"}>
                      {new Date(viewingImage.medicine.nearestExpiry).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
                      ({Math.max(0, Math.ceil((new Date(viewingImage.medicine.nearestExpiry).getTime() - Date.now()) / 86400000))}d left)
                    </span>
                  </div>
                )}
                {viewingImage.medicine.prescriptionRequired && (
                  <div className="flex justify-between"><span className="text-ink-900/50">Rx Required</span><span className="text-amber-700 font-medium">Yes</span></div>
                )}
              </div>
              <button
                onClick={() => { if (viewingImage.medicine.totalStock > 0) { addToCart(viewingImage.medicine); setViewingImage(null); } }}
                disabled={viewingImage.medicine.totalStock <= 0}
                className="w-full mt-2 py-2 rounded-lg bg-pine-600 hover:bg-pine-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium transition"
              >
                {viewingImage.medicine.totalStock <= 0 ? "Out of Stock" : "Add to Cart"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {expandedProduct && (
        <Modal open onClose={() => setExpandedProduct(null)} title={expandedProduct.name} size="lg">
          <div className="space-y-4 text-sm">
            <div className="flex gap-4">
              {expandedProduct.imageUrl && (
                <img src={expandedProduct.imageUrl} alt={expandedProduct.name} className="w-24 h-24 rounded-lg object-cover border border-sand-200 flex-shrink-0" />
              )}
              <div className="flex-1">
                <div className="text-ink-900 font-medium text-base">{expandedProduct.name}</div>
                {expandedProduct.genericName && <div className="text-ink-900/50 text-xs mt-0.5">{expandedProduct.genericName}</div>}
                <div className="flex items-center gap-2 mt-2">
                  {expandedProduct.form && <span className="text-[10px] bg-sand-100 text-ink-900/50 px-1.5 py-0.5 rounded">{expandedProduct.form}</span>}
                  {expandedProduct.prescriptionRequired && <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full font-medium">Rx</span>}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-sand-50 rounded-lg px-3 py-2">
                <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Selling Price</div>
                <div className="text-pine-700 font-semibold">{ghs(expandedProduct.sellingPrice)}</div>
              </div>
              <div className="bg-sand-50 rounded-lg px-3 py-2">
                <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Cost Price</div>
                <div className="font-semibold">{ghs(expandedProduct.purchasePrice)}</div>
              </div>
              <div className="bg-sand-50 rounded-lg px-3 py-2">
                <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Stock</div>
                <div className={`font-semibold ${expandedProduct.totalStock <= 10 ? "text-clay-600" : "text-ink-900"}`}>
                  {expandedProduct.totalStock} {expandedProduct.totalStock <= 0 ? "(Out of stock)" : "in stock"}
                </div>
              </div>
              <div className="bg-sand-50 rounded-lg px-3 py-2">
                <div className="text-[10px] text-ink-900/40 uppercase tracking-wide">Reorder Level</div>
                <div className="font-semibold">{expandedProduct.reorderLevel}</div>
              </div>
            </div>
            <div className="space-y-1.5 text-xs">
              {expandedProduct.barcode && (
                <div className="flex justify-between"><span className="text-ink-900/50">Barcode</span><span className="font-mono text-ink-900">{expandedProduct.barcode}</span></div>
              )}
              <div className="flex justify-between"><span className="text-ink-900/50">SKU</span><span className="font-mono text-ink-900">{expandedProduct.sku}</span></div>
              {expandedProduct.strength && (
                <div className="flex justify-between"><span className="text-ink-900/50">Strength</span><span className="text-ink-900">{expandedProduct.strength}</span></div>
              )}
              {expandedProduct.dosage && (
                <div className="flex justify-between"><span className="text-ink-900/50">Dosage</span><span className="text-ink-900">{expandedProduct.dosage}</span></div>
              )}
              {expandedProduct.brand && (
                <div className="flex justify-between"><span className="text-ink-900/50">Brand</span><span className="text-ink-900">{expandedProduct.brand}</span></div>
              )}
              {expandedProduct.manufacturer && (
                <div className="flex justify-between"><span className="text-ink-900/50">Manufacturer</span><span className="text-ink-900">{expandedProduct.manufacturer}</span></div>
              )}
              {expandedProduct.nearestExpiry && (
                <div className="flex justify-between">
                  <span className="text-ink-900/50">Expiry</span>
                  <span className={Math.ceil((new Date(expandedProduct.nearestExpiry).getTime() - Date.now()) / 86400000) <= 30 ? "text-clay-600 font-medium" : "text-ink-900"}>
                    {new Date(expandedProduct.nearestExpiry).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
                    ({Math.max(0, Math.ceil((new Date(expandedProduct.nearestExpiry).getTime() - Date.now()) / 86400000))}d left)
                  </span>
                </div>
              )}
              {expandedProduct.description && (
                <div className="mt-2 pt-2 border-t border-sand-100">
                  <span className="text-ink-900/50">Description</span>
                  <p className="text-ink-900 mt-1">{expandedProduct.description}</p>
                </div>
              )}
            </div>
            <button
              onClick={() => { if (expandedProduct.totalStock > 0) { addToCart(expandedProduct); setExpandedProduct(null); } }}
              disabled={expandedProduct.totalStock <= 0}
              className="w-full py-2.5 rounded-lg bg-pine-600 hover:bg-pine-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium transition"
            >
              {expandedProduct.totalStock <= 0 ? "Out of Stock" : "Add to Cart"}
            </button>
          </div>
        </Modal>
      )}

      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}
    </div>
  );
}

function PaymentModal({ total, initialMethod = "cash", onConfirm, onCancel }: { total: number; initialMethod?: SalePayment["method"]; onConfirm: (payments: SalePayment[], amountReceived?: number) => void; onCancel: () => void }) {
  const [payments, setPayments] = useState<SalePayment[]>([{ method: initialMethod, amount: total, date: new Date().toISOString() }]);
  const [cashReceived, setCashReceived] = useState<string>(String(Math.ceil(total)));
  const [showKeypad, setShowKeypad] = useState(false);
  const isCash = payments.length === 1 && payments[0].method === "cash";
  const totalPaid = payments.reduce((s, p) => s + p.amount, 0);
  const change = Math.max(0, (isCash ? parseFloat(cashReceived) || 0 : totalPaid) - total);
  const balance = total - totalPaid;

  function addPayment() {
    setPayments((prev) => [...prev, { method: "card", amount: 0, date: new Date().toISOString() }]);
  }

  function updatePayment(i: number, field: keyof SalePayment, value: string | number) {
    setPayments((prev) => prev.map((p, idx) => idx === i ? { ...p, [field]: value } : p));
  }

  function removePayment(i: number) {
    if (payments.length <= 1) return;
    setPayments((prev) => prev.filter((_, idx) => idx !== i));
  }

  const valid = payments.length > 0 && totalPaid >= total && payments.every((p) => p.amount > 0);

  return (
    <Modal open onClose={onCancel} title="Payment" size="md">
      <div className="text-center">
        <span className="text-3xl font-display text-pine-700 tabular-nums">{ghs(total)}</span>
      </div>

      <div className="space-y-3">
        {payments.map((p, i) => (
          <div key={i} className="flex gap-2 items-start">
            <select
              value={p.method}
              onChange={(e) => updatePayment(i, "method", e.target.value)}
              className="flex-1 px-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
              aria-label={`Payment ${i + 1} method`}
            >
              {PAY_METHODS.map((m) => (
                <option key={m.key} value={m.key}>{m.label}</option>
              ))}
            </select>
            <input
              type="number"
              value={p.amount || ""}
              onChange={(e) => updatePayment(i, "amount", Math.max(0, Number(e.target.value)))}
              placeholder="Amount"
              aria-label={`Payment ${i + 1} amount`}
              className="w-24 px-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 tabular-nums transition"
            />
            {p.method !== "cash" && (
              <input
                value={p.reference || ""}
                onChange={(e) => updatePayment(i, "reference", e.target.value)}
                placeholder="Ref #"
                aria-label={`Payment ${i + 1} reference`}
                className="w-28 px-3 py-2 rounded-lg border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 transition"
              />
            )}
            {payments.length > 1 && (
              <button onClick={() => removePayment(i)} className="text-ink-900/30 hover:text-clay-600 mt-1 focus:outline-none focus:ring-2 focus:ring-clay-500/30 rounded p-0.5" aria-label="Remove payment">
                <Trash2 size={14} />
              </button>
            )}
          </div>
        ))}
      </div>

      <button onClick={addPayment} className="w-full text-xs text-pine-700 hover:text-pine-800 focus:outline-none focus:ring-2 focus:ring-pine-500/30 rounded py-1">
        + Add another payment
      </button>

      {isCash && (
        <div className="space-y-2 border-t border-sand-200 pt-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-ink-900/50">Cash received</span>
            <div className="flex items-center gap-2">
              <input
                type="number"
                value={cashReceived}
                onChange={(e) => setCashReceived(e.target.value)}
                aria-label="Cash received"
                className="w-28 text-right px-2 py-1 rounded border border-sand-200 text-sm outline-none focus:border-pine-500 focus:ring-2 focus:ring-pine-500/20 tabular-nums transition"
              />
              <button
                type="button"
                onClick={() => setShowKeypad(!showKeypad)}
                className={`p-1.5 rounded-lg transition focus:outline-none focus:ring-2 focus:ring-pine-500/30 ${showKeypad ? "bg-pine-100 text-pine-700" : "text-ink-900/30 hover:text-ink-900/60"}`}
                aria-label="Toggle keypad"
              >
                <Keyboard size={16} />
              </button>
            </div>
          </div>
          {showKeypad && (
            <NumericKeypad
              value={cashReceived}
              onChange={setCashReceived}
              onConfirm={() => setShowKeypad(false)}
              className="mt-2"
            />
          )}
          {change > 0 && (
            <div className="flex items-center justify-between text-sm font-medium text-pine-700">
              <span>Change</span>
              <span className="tabular-nums">{ghs(change)}</span>
            </div>
          )}
        </div>
      )}

      <div className="border-t border-sand-200 pt-3 space-y-1 text-sm">
        <div className="flex justify-between text-ink-900/50">
          <span>Total paid</span>
          <span className="tabular-nums">{ghs(totalPaid)}</span>
        </div>
        {balance > 0 && (
          <div className="flex justify-between text-clay-600">
            <span>Balance due</span>
            <span className="tabular-nums">{ghs(balance)}</span>
          </div>
        )}
      </div>

      <Button
        onClick={() => {
          const amt = isCash ? parseFloat(cashReceived) || 0 : totalPaid;
          onConfirm(payments, isCash ? amt : undefined);
        }}
        disabled={!valid}
        className="w-full"
        size="lg"
      >
        Confirm payment
      </Button>
    </Modal>
  );
}

function HeldSalesModal({ heldSales, onResume, onResumeWithPayment, onDelete, onClose }: {
  heldSales: HeldSale[];
  onResume: (h: HeldSale) => void;
  onResumeWithPayment: (h: HeldSale, payments: SalePayment[], amountReceived?: number) => void;
  onDelete: (h: HeldSale) => void;
  onClose: () => void;
}) {
  return (
    <Modal open onClose={onClose} title="Held Sales" size="md">
      {heldSales.length === 0 ? (
        <p className="text-sm text-ink-900/35 py-6 text-center">No held sales</p>
      ) : (
        <div className="space-y-3">
          {heldSales.map((h) => (
            <div key={h._id} className="border border-sand-200 rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-ink-900">{h.transactionNumber}</span>
                <span className="font-semibold text-pine-700 tabular-nums">{ghs(h.total)}</span>
              </div>
              <div className="text-xs text-ink-900/40">
                {h.items.length} item(s) — {new Date(h.createdAt).toLocaleString()}
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => onResumeWithPayment(h, [{ method: "cash", amount: h.total, date: new Date().toISOString() }], h.total)}
                  className="flex-1"
                >
                  Pay now
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => onDelete(h)}
                  className="text-clay-600 border-clay-200 hover:bg-clay-50"
                >
                  Delete
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
      </div>
    </Modal>
  );
}

function ReceiptModal({ receipt, onClose }: { receipt: SaleReceipt; onClose: () => void }) {
  function handlePrint() {
    const win = window.open("", "_blank", "width=400,height=600");
    if (!win) return;
    const logoHtml = receipt.logoUrl ? `<img src="${receipt.logoUrl}" style="max-height:60px;margin:0 auto 8px;display:block" />` : "";
    win.document.write(`<html><head><title>Receipt</title><style>
      body{font-family:monospace;padding:16px;max-width:300px;margin:0 auto;font-size:12px}
      .center{text-align:center} .line{border-top:1px dashed #ccc;margin:8px 0}
      .row{display:flex;justify-content:space-between}
      .bold{font-weight:bold} .small{font-size:10px;color:#666}
    </style></head><body>
      <div class="center">${logoHtml}<b>${receipt.name}</b><br><span class="small">${receipt.address}<br>${receipt.phone}</span></div>
      <div class="line"></div>
      <div class="row"><span>Receipt:</span><span>${receipt.receipt}</span></div>
      <div class="row"><span>Date:</span><span>${new Date(receipt.date).toLocaleString()}</span></div>
      <div class="row"><span>Cashier:</span><span>${receipt.cashier}</span></div>
      ${receipt.customer ? `<div class="row"><span>Customer:</span><span>${receipt.customer}</span></div>` : ""}
      <div class="line"></div>
      ${receipt.items.map((it) => `<div class="row"><span>${it.name} x${it.quantity}</span><span>${ghs(it.subtotal)}</span></div>`).join("")}
      <div class="line"></div>
      <div class="row"><span>Subtotal</span><span>${ghs(receipt.subtotal)}</span></div>
      ${receipt.discount > 0 ? `<div class="row"><span>Discount</span><span>-${ghs(receipt.discount)}</span></div>` : ""}
      ${receipt.tax > 0 ? `<div class="row"><span>Tax</span><span>${ghs(receipt.tax)}</span></div>` : ""}
      <div class="row bold"><span>Total</span><span>${ghs(receipt.total)}</span></div>
      <div class="line"></div>
      <div class="bold" style="font-size:11px;margin-bottom:2px">Payment</div>
      ${receipt.payments.map((p) => `<div class="row"><span>${p.method.replace(/_/g," ").replace(/\b\w/g,(c:string)=>c.toUpperCase())}</span><span>${ghs(p.amount)}${p.reference ? ` (${p.reference})` : ""}</span></div>`).join("")}
      ${receipt.amountReceived != null ? `<div class="row"><span>Received</span><span>${ghs(receipt.amountReceived)}</span></div>` : ""}
      ${receipt.change != null && receipt.change > 0 ? `<div class="row bold"><span>Change</span><span>${ghs(receipt.change)}</span></div>` : ""}
      <div class="line"></div>
      <div class="center small">Thank you for your purchase!</div>
    </body></html>`);
    win.document.close();
    win.print();
  }

  return (
    <Modal open onClose={onClose} title={receipt.name} size="sm">
      {receipt.logoUrl && (
        <div className="flex justify-center mb-2">
          <img src={receipt.logoUrl} alt={receipt.name} className="h-12 object-contain" />
        </div>
      )}
      <div className="text-center space-y-1 mb-4">
        <p className="text-xs text-ink-900/40">{receipt.address}</p>
        <p className="text-xs text-ink-900/40">{receipt.phone}</p>
      </div>

      <div className="border-t border-dashed border-sand-200 pt-3 space-y-2 text-sm">
        <div className="flex justify-between text-ink-900/50"><span>Receipt</span><span>{receipt.receipt}</span></div>
        <div className="flex justify-between text-ink-900/50"><span>Date</span><span>{new Date(receipt.date).toLocaleString()}</span></div>
        <div className="flex justify-between text-ink-900/50"><span>Cashier</span><span>{receipt.cashier}</span></div>
        {receipt.customer && <div className="flex justify-between text-ink-900/50"><span>Customer</span><span>{receipt.customer}</span></div>}
      </div>

      <div className="border-t border-dashed border-sand-200 pt-3 space-y-2">
        {receipt.items.map((it, i) => (
          <div key={i} className="flex justify-between text-sm">
            <span className="text-ink-900">{it.name} x{it.quantity}</span>
            <span className="text-ink-900 tabular-nums">{ghs(it.subtotal)}</span>
          </div>
        ))}
      </div>

      <div className="border-t border-dashed border-sand-200 pt-3 space-y-1 text-sm">
        <div className="flex justify-between text-ink-900/50"><span>Subtotal</span><span className="tabular-nums">{ghs(receipt.subtotal)}</span></div>
        {receipt.discount > 0 && <div className="flex justify-between text-clay-600"><span>Discount</span><span className="tabular-nums">-{ghs(receipt.discount)}</span></div>}
        {receipt.tax > 0 && <div className="flex justify-between text-ink-900/50"><span>Tax</span><span className="tabular-nums">{ghs(receipt.tax)}</span></div>}
        <div className="flex justify-between font-semibold text-ink-900 pt-1"><span>Total</span><span className="tabular-nums">{ghs(receipt.total)}</span></div>
        <div className="border-t border-dashed border-sand-200 mt-2 pt-2 space-y-1">
          <div className="text-xs font-semibold text-ink-900/70 uppercase tracking-wide">Payment</div>
          {receipt.payments.map((p, i) => (
            <div key={i} className="flex justify-between text-ink-900/50">
              <span className="capitalize">{p.method.replace("_", " ")}</span>
              <span className="tabular-nums">{ghs(p.amount)}{p.reference ? ` (${p.reference})` : ""}</span>
            </div>
          ))}
        </div>
        {receipt.amountReceived != null && (
          <div className="flex justify-between text-ink-900/50"><span>Received</span><span className="tabular-nums">{ghs(receipt.amountReceived)}</span></div>
        )}
        {receipt.change != null && receipt.change > 0 && (
          <div className="flex justify-between font-medium text-pine-700"><span>Change</span><span className="tabular-nums">{ghs(receipt.change)}</span></div>
        )}
      </div>

      <div className="text-center text-xs text-ink-900/30 pt-2 border-t border-sand-200">
        Thank you for your purchase!
      </div>

      <div className="flex gap-2">
        <Button variant="secondary" onClick={handlePrint} className="flex-1">Print receipt</Button>
        <Button onClick={onClose} className="flex-1">Close</Button>
      </div>
    </Modal>
  );
}
